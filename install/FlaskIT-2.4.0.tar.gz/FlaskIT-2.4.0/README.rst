===============
 FlaskIT async
===============

Quick Howto
===========

Create a new api::

  ./bootstrap/flaskit_new_api.py --name test-api --nomkvenv --nogit --dir ./test-api

The ``--nogit`` avoids initializing a git repo, it's for testing only. If you
intend to create a real API, leave it.

Add a resource to the API::

  ./bootstrap/flaskit_add_resource.py --dir ./test-api --resource resource-one

You also have to specify the types of requests you want to handle (``--get``,
``--post``, ``--put``, ``delete`` or ``--all``)

NOTE(lpeschke): I added ``j2render*`` and vars.py to the ``boostrap`` directory
(and modified the hardcoded ``J2RENDER`` path in ``flaskit_new*``) in order to
ease development.
