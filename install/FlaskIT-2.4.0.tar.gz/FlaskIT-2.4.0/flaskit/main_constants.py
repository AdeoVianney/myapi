import os

####################################
# Flaskit constants
####################################

FLASKIT_NAME = "flaskit"

FLASKIT_VERSION = "2.4.0"

FLASKIT_LOCAL_DIR = os.path.dirname(os.path.realpath("%s/.." % __file__))
