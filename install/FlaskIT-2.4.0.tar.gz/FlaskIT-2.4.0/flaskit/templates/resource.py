# Flask imports
from flask import g
import flask_restful as restful
from flask_restful import marshal

# Flaskit imports
from flaskit import app
from flaskit.utils import ErrorNotFound
from flaskit.resource import MetaResource, init_api, generate_swagger_from_schema

# Project imports
from resources.structs import _MetadataFields

# Python imports
import sys
import copy
import json


{% if get %}
#=========================
# {{resource|camelcaseformat}}Get swagger fields
#=========================
@generate_swagger_from_schema(schemaRef="{{resource|camelcaseformat}}List", schemaPath="definitions/response/properties/{{resource}}s/items")
class {{resource|camelcaseformat}}GetResponseFields:
    pass
{% endif %}

{%- if list %}
#=========================
# {{resource|camelcaseformat}}List swagger fields
#=========================
@generate_swagger_from_schema(schemaRef="{{resource|camelcaseformat}}List", schemaPath="definitions/response/properties/_metadata")
class {{resource|camelcaseformat}}ListResponseMetadataFields:
    pass

@generate_swagger_from_schema(schemaRef="{{resource|camelcaseformat}}List", schemaPath="definitions/response")
class {{resource|camelcaseformat}}ListResponseFields:
    pass
{% endif %}

{%- if post %}
#=========================
# {{resource|camelcaseformat}}Post swagger fields
#=========================
@generate_swagger_from_schema(schemaRef="{{resource|camelcaseformat}}Post", schemaPath="")
class {{resource|camelcaseformat}}PostFields:
    pass

@generate_swagger_from_schema(schemaRef="{{resource|camelcaseformat}}Post", schemaPath="definitions/response/properties/_metadata")
class {{resource|camelcaseformat}}PostResponseMetadataFields:
    pass

@generate_swagger_from_schema(schemaRef="{{resource|camelcaseformat}}Post", schemaPath="definitions/response")
class {{resource|camelcaseformat}}PostResponseFields:
    pass
{% endif %}

{%- if delete %}
#=========================
# {{resource|camelcaseformat}}Delete swagger fields
#=========================
@generate_swagger_from_schema(schemaRef="{{resource|camelcaseformat}}Delete", schemaPath="definitions/response/properties/_metadata")
class {{resource|camelcaseformat}}DeleteResponseMetadataFields:
    pass

@generate_swagger_from_schema(schemaRef="{{resource|camelcaseformat}}Delete", schemaPath="definitions/response")
class {{resource|camelcaseformat}}DeleteResponseFields:
    pass
{% endif %}

{%- if put  %}
#=========================
# {{resource|camelcaseformat}}Put swagger fields
#=========================
@generate_swagger_from_schema(schemaRef="{{resource|camelcaseformat}}Put", schemaPath="")
class {{resource|camelcaseformat}}PutFields:
    pass

@generate_swagger_from_schema(schemaRef="{{resource|camelcaseformat}}Put", schemaPath="definitions/response/properties/_metadata")
class {{resource|camelcaseformat}}PutResponseMetadataFields:
    pass

@generate_swagger_from_schema(schemaRef="{{resource|camelcaseformat}}Put", schemaPath="definitions/response")
class {{resource|camelcaseformat}}PutResponseFields:
    pass
{% endif %}


{%- if list_or_post %}
##################################################################################################
# {{resource|camelcaseformat}} resource for list and post verbs
##################################################################################################
class {{resource|camelcaseformat}}(MetaResource):
    """Manage {{resource}}
    """
{%- if list %}
    @init_api("{{resource|camelcaseformat}}List")
    def get(self):
        """List {{resource}}s

        List all or partial {{resource}}s

        TITLE:Sample
        <pre>
        CURL:"/{{resource}}"
        </pre>
        """

        self.initializeAPI()

        # to complete
        data = {}

        code = 200
        response = {
            "{{resource}}s": marshal(data, {{resource|camelcaseformat}}GetResponseFields.resource_fields),
            "_metadata": { "count": len(data) }
        }

        # add metadatas
        response["_metadata"]["status"] = 0
        return(response, code)
{% endif %}

{%- if post  %}
    @init_api("{{resource|camelcaseformat}}Post")
    def post(self):
        """Create a {{resource}}

        TITLE:Sample
        <pre>
        CURL:"/{{resource}}" -d '{"{{resource}}": "to complete"}'
        </pre>
        """

        self.initializeAPI()

        # to complete
        {{resource|camelcaseformat}}Record = {}

        if {{resource|camelcaseformat}}Record is not None:
            ErrorDuplicate("{{resource}} '%s' already exist" % g.args["{{resource|camelcaseformat}}"])

        # create object
        if not g.dryrun:
            # create object command
            pass

        response = marshal({{resource|camelcaseformat}}Record, {{resource|camelcaseformat}}GetResponseFields.resource_fields)

        # global response
        metadatas = {}
        metadatas["message"] = "Successfully created"
        metadatas["status"] = 0
        response["_metadata"] = metadatas
        return(response)
{% endif %}
{% endif %}

{%- if get_or_put_or_delete %}
##################################################################################################
# Qualified {{resource|camelcaseformat}} for get, put, and delete verbs
##################################################################################################
class {{resource|camelcaseformat}}ById(MetaResource):
    """Manage qualified {{resource|camelcaseformat}}
    """
{%- if get  %}
    @init_api("{{resource|camelcaseformat}}Get")
    def get(self, {{resource}}):
        """Get {{resource}}

        Get {{resource}} informations

        TITLE:Sample
        <pre>
        CURL:"/{{resource}}/id"
        </pre>
        """

        # verify request
        self.initializeAPI(data = { "{{resource}}": {{resource}} })

        # to complete
        {{resource|camelcaseformat}}Record = {}

        if {{resource|camelcaseformat}}Record is None:
            ErrorNotFound("{{resource|camelcaseformat}} '%s' does not exist" % {{resource}})

        # response format
        response = marshal({{resource|camelcaseformat}}Record, {{resource|camelcaseformat}}GetResponseFields.resource_fields)
        return(response)
{% endif %}

{%- if delete  %}
    @init_api("{{resource|camelcaseformat}}Delete")
    def delete(self, {{resource}}):
        """Delete a {{resource}}

        TITLE:Sample
        <pre>
        CURL:"/{{resource}}/id" -X DELETE
        </pre>
        """

        # verify request
        self.initializeAPI(data = { "{{resource}}": {{resource}} })

        # to complete
        {{resource|camelcaseformat}}Record = {}
        if {{resource|camelcaseformat}}Record is None:
            ErrorNotFound("{{resource}} '%s' does not exist" % {{resource}})

        # remove object
        if not g.dryrun:
            # remove object command
            pass


        # response format
        response = marshal({{resource|camelcaseformat}}Record, {{resource|camelcaseformat}}GetResponseFields.resource_fields)

        # global response
        metadatas = {}
        metadatas["message"] = "Successfully deleted"
        metadatas["status"] = 0
        response["_metadata"] = metadatas
        return(response)
{% endif %}

{%- if put  %}
    @init_api("{{resource|camelcaseformat}}Put")
    def put(self, {{resource}}):
        """Update a {{resource}}

        TITLE:Sample
        <pre>
        CURL:"/{{resource}}/id" -X PUT'
        </pre>
        """

        # verify request
        self.initializeAPI(data = { "{{resource}}": {{resource}} })

        # to complete
        {{resource|camelcaseformat}}Record = {}
        if {{resource|camelcaseformat}}Record is None:
            ErrorNotFound("{{resource}} '%s' does not exist" % {{resource}})

        # remove object
        if not g.dryrun:
            # remove object command
            pass

        # response format
        response = marshal({{resource|camelcaseformat}}Record, {{resource|camelcaseformat}}GetResponseFields.resource_fields)

        # global response
        metadatas = {}
        metadatas["message"] = "Successfully modified"
        metadatas["status"] = 0
        response["_metadata"] = metadatas
        return(response)
{% endif %}
{% endif %}
