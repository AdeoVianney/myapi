# Flask imports
from flask import request, g, current_app
import flask_restful as restful

# Flaskit imports
from flaskit import app
from flaskit.logger import loglevels
from flaskit.cache import gGet, gSet

# Python imports
import re
import time
import glob
import dpath
import ujson


class DynRules():
    def reloadDB(self):

        # Load DB (with expiration)
        self.db = gGet("dynrules.db")
        if self.db is None:
            #app.logger.debug("Reload dynrules DB")
            self.db = self.loadFiles()
            gSet("dynrules.db", self.db, timeout=app.config["CACHE_TIMEOUT_DB_DYNRULES"])

    def loadFiles(self):
        # reload authorization configuration files
        try:
            if app.config["DYNRULES_CONFIG_DIR"][0] == "/":
                dynrules_dir = app.config["DYNRULES_CONFIG_DIR"]
            else:
                dynrules_dir = "%s/%s" % (app.config["LOCAL_DIR"], app.config["DYNRULES_CONFIG_DIR"])
        except Exception, e:
            app.logger.error("Unable to define dynrules db dir (%s)" % e)
            return

        dynrules = []
        try:
            for filename in glob.glob("%s/*.rules" % dynrules_dir):
                dynrules.extend(self.loadFile(filename))

        except Exception, e:
            app.logger.error("Unable to read dynrules db files  (%s)" % e)
            return

        return dynrules

    def loadFile(self, filename):

        # List of regexp that validate all possibles formats
        lst_regexp = []
        lst_regexp.append(re.compile("^(?P<keyfilter>\w+)(?P<op>==|!=|=~~|!~~|=~|!~)(?P<val>.+)$"))
        lst_regexp.append(re.compile("^(?P<prefix>(@|@@))(?P<keyfilter>[\w/]+)(?P<op>==|!=|=~~|!~~|=~|!~)(?P<val>.+)$"))
        lst_regexp.append(re.compile("^(?P<keyaction>\w+)(?P<op>=)(?P<val>.+)$"))

        list = []
        try:
            file = open(filename, "r")
            for line in file:
                line = line.strip()

                # skip blank lines and comments
                if len(line) == 0 or line[0] == "#":
                    continue

                # split line into individual fields to filter each one
                filters = []
                actions = []
                opt = line.split(",")
                try:
                    # loop over each field
                    for o in opt:
                        o = o.strip()

                        # Validate format based on list of regexp
                        for r in lst_regexp:
                            m = r.search(o)
                            if m is not None:
                                break
                        if m is None:
                            # No matching regexp : bad format
                            app.logger.error("Invalid format (no matching regexp for %s) (%s)" % (o, line))
                            break

                        # process action field : <filter><op><val>
                        # split into internal dict for easy browsing
                        if "keyfilter" in m.groupdict():
                            opts = {}
                            if m.group("op") == "=~" or m.group("op") == "!~":
                                # verif and precompil regexp
                                try:
                                    r = re.compile(m.group("val"))
                                except:
                                    raise Exception("Invalid regexp %s in %s" % (m.group("val"), line))
                                filter = {"key": m.group("keyfilter"), "op": m.group("op"), "val": r,
                                          "info": m.group("val")}
                            else:
                                filter = {"key": m.group("keyfilter"), "op": m.group("op"), "val": m.group("val")}

                            if "prefix" in m.groupdict():
                                filter["prefix"] = m.group("prefix")
                            else:
                                filter["prefix"] = ""
                            filters.append(filter)

                        # process action field : <action>=<val>:<key1>=<val1>:<key2>=<val2>...
                        # split into internal dict for easy browsing
                        if "keyaction" in m.groupdict():
                            opt = m.group("val").split(":")
                            opts = {"key": m.group("keyaction"), "op": m.group("op"), "val": opt[0], "opts": {}}
                            opt = opt[1:]
                            for p in opt:
                                f = p.split("=")
                                if len(f) == 1:
                                    opts["opts"][f[0]] = True
                                else:
                                    opts["opts"][f[0]] = f[1]
                            actions.append(opts)

                except Exception as e:
                    app.logger.exception(e)
                    raise

                if len(filters) == 0 or len(actions) == 0:
                    app.logger.error("Missing filter/action fields in %s" % line)
                    continue

                list.append({'info': line, 'filters': filters, 'actions': actions})
            file.close()
        except Exception as e:
            app.logger.exception(e)
            raise Exception("Error reading file '%s' (%s). Skip it" % (filename, e))

        return list

    def eval(self, response=None):

        g.dynrules = []

        # cache already evaluated rules (to skip in post evaluation)
        if "dynrules_cached" not in g:
            g.dynrules_cached = {}

        # load message filter
        self.reloadDB();
        list = self.db

        if len(list) == 0:
            return

        # Create arrays of things to verif for each operator supported
        for filter in list:
            found = True

            # all criteria of filter must match
            for f in filter["filters"]:
                try:
                    # key not found
                    if f["key"] == "API" and "apiname" in g:
                        val = g.apiname
                    elif f["key"] == "USER" and "username" in g:
                        val = g.username
                    elif f["key"] == "USERFAMILY" and "userfamily" in g:
                        val = g.userfamily
                    elif f["key"] == "ENV":
                        val = current_app.config["ENV"]
                    elif f["key"] == "IP":
                        val = g.remote_addr
                    elif f["key"] == "METHOD":
                        val = request.method
                    elif f["key"] == "URL":
                        val = request.url
                    elif f["key"] == "REQBODY":
                        val = request.data
                    elif f["key"] == "REQHEAD":
                        val = ""
                        for x in request.headers:
                            val += "%s: %s\n" % (x[0], x[1])
                    elif f["key"] == "RSP" and response is not None:
                        val = "1"
                    elif f["key"] == "RSPCODE" and response is not None:
                        val = str(response.status_code)
                    elif f["key"] == "RSPBODY" and response is not None:
                        val = response.data
                    elif f["key"] == "RSPHEAD" and response is not None:
                        val = ""
                        for x in response.headers:
                            val += "%s: %s\n" % (x[0], x[1])
                    elif f["prefix"] == "@" and request.data != "":
                        try:
                            jdata = ujson.loads(request.data)
                        except Exception:
                            app.logger.error(
                                "Unable to evaluate field '%s' (invalid json request message). Skip" % f["key"])
                            found = False
                            break
                        try:
                            val = str(dpath.util.get(jdata, f["key"]))
                        except ValueError:
                            app.logger.error("Unable to evaluate field '%s' in json request message. Skip" % f["key"])
                            found = False
                        except Exception, e:
                            app.logger.exception(e)
                            app.logger.error("Unable to evaluate field '%s'. Skip" % f["key"])
                            found = False
                    elif f["prefix"] == "@@" and response is not None:
                        try:
                            jdata = ujson.loads(response.data)
                        except Exception:
                            app.logger.error(
                                "Unable to evaluate field '%s' (invalid json response message). Skip" % f["key"])
                            found = False
                            break
                        try:
                            val = str(dpath.util.get(jdata, f["key"]))
                        except ValueError, e:
                            app.logger.exception(e)
                            app.logger.error("Unable to evaluate field '%s' in json response message. Skip" % f["key"])
                            found = False
                        except Exception, e:
                            app.logger.exception(e)
                            app.logger.error("Unable to evaluate field '%s'. Skip" % f["key"])
                            found = False
                    else:
                        found = False
                        break
                except Exception, e:
                    app.logger.exception(e)
                    found = False
                    break

                if f["op"] == "==" and not f["val"] == val:
                    found = False
                    break
                if f["op"] == "!=" and not f["val"] != val:
                    found = False
                    break
                if f["op"] == "=~" and not re.search(f["val"], val):
                    found = False
                    break
                if f["op"] == "!~" and re.search(f["val"], val):
                    found = False
                    break
                if f["op"] == "=~~" and not re.search(f["val"], val, re.IGNORECASE):
                    found = False
                    break
                if f["op"] == "!~~" and re.search(f["val"], val, re.IGNORECASE):
                    found = False
                    break

            # not matching. try next rule
            if not found:
                app.logger.debug("dynrules : non matching rule. Skip it (%s)" % filter["info"])
                continue

            if filter["info"] not in g.dynrules_cached:
                app.logger.info("dynrules : found matching rule (%s)" % filter["info"])
                g.dynrules.append(filter)
                g.dynrules_cached[filter["info"]] = 1

            continue

        # execution of configuration actions
        self.exec_cfg(response)

        return

    def exec_cfg(self, response):

        # Execute action
        for rule in g.dynrules:
            for action in rule["actions"]:

                # nocache
                if action["key"] == "NOCACHE":
                    if action["val"] == "1":
                        g.nocache = True
                    else:
                        g.nocache = False

                # dryrun
                if action["key"] == "DRYRUN":
                    if action["val"] == "1":
                        g.dryrun = True
                    else:
                        g.dryrun = False

                # logbody
                if action["key"] == "LOGBODY":
                    g.logbody = int(action["val"])

                # logrequest
                if action["key"] == "LOGREQUEST":
                    g.logrequest = int(action["val"])

                # audit
                if action["key"] == "AUDIT":
                    g.API["audit"] = int(action["val"])
                    g.Audit.evaluate()

                # stats
                if action["key"] == "STATS":
                    if action["val"] == "1":
                        g.API["stats"] = True
                    else:
                        g.API["stats"] = False

                # statsd
                if action["key"] == "STATSD":
                    if action["val"] == "1":
                        g.API["statsd"] = True
                    else:
                        g.API["statsd"] = False

                # debug
                if action["key"] == "DEBUG":
                    if action["val"] == "0":
                        g.loglevel = "INFO"
                    elif action["val"] == "1":
                        g.loglevel = "DEBUG"
                    elif action["val"] == "2":
                        g.loglevel = "DEBUG2"

        return

    def exec_pre(self):

        # Execute action
        for rule in g.dynrules:
            for action in rule["actions"]:

                # sleep
                if action["key"] == "SLEEP":
                    time.sleep(int(action["val"]))

                # error
                if action["key"] == "ERROR":

                    if "status" in action["opts"]:
                        g.response_status = int(action["opts"]["status"])
                    else:
                        g.response_status = 2

                    if "message" in action["opts"]:
                        g.response_message = "%s [uuid:%s]" % (action["opts"]["message"], g.uuid)
                    else:
                        g.response_message = "Generated Error [uuid:%s]" % g.uuid

                    restful.abort(int(action["val"]),
                                  _metadata={"status": g.response_status, "message": "%s" % g.response_message})

                # log
                if action["key"] == "LOG":
                    if "level" not in action["opts"]:
                        action["opts"]["level"] = "INFO"
                    if action["opts"]["level"] not in loglevels:
                        action["opts"]["level"] = "INFO"
                    app.logger.log(loglevels[action["opts"]["level"]], "%s" % action["val"])

                # ADDREQFIELD
                if action["key"] == "ADDREQFIELD":
                    # Set or create entry
                    jdata = ujson.loads(request.data)
                    nb = dpath.util.set(jdata, action["val"], action["opts"]["value"])
                    if nb == 0:
                        dpath.util.new(jdata, action["val"], action["opts"]["value"])

                    # reformat
                    g.data = ujson.dumps(jdata)
                    g.request_tainted = True

        return

    def exec_post(self, response):

        # reevaluation of rules with response
        self.eval(response)

        # Execute action
        for rule in g.dynrules:
            for action in rule["actions"]:

                # sleep
                if action["key"] == "SLEEP":
                    time.sleep(int(action["val"]))

                # error
                if action["key"] == "ERROR":

                    if "status" in action["opts"]:
                        g.response_status = int(action["opts"]["status"])
                    else:
                        g.response_status = 2

                    if "message" in action["opts"]:
                        g.response_message = "%s [uuid:%s]" % (action["opts"]["message"], g.uuid)
                    else:
                        g.response_message = "Generated Error [uuid:%s]" % g.uuid

                    restful.abort(int(action["val"]),
                                  _metadata={"status": g.response_status, "message": "%s" % g.response_message})

                # log
                if action["key"] == "LOG":
                    if "level" not in action["opts"]:
                        action["opts"]["level"] = "INFO"
                    if action["opts"]["level"] not in loglevels:
                        action["opts"]["level"] = "INFO"
                    app.logger.log(loglevels[action["opts"]["level"]], "%s" % action["val"])

                # add header
                if action["key"] == "ADDHEAD":
                    if "value" in action["opts"]:
                        response.headers.add(action["val"], action["opts"]["value"])
                    else:
                        response.headers.add(action["val"], "1")

                # ADDRSPFIELD
                if action["key"] == "ADDRSPFIELD":
                    # Set or create entry
                    jdata = ujson.loads(response.data)
                    nb = dpath.util.set(jdata, action["val"], action["opts"]["value"])
                    if nb == 0:
                        dpath.util.new(jdata, action["val"], action["opts"]["value"])

                    # reformat
                    response.data = ujson.dumps(jdata)

        return
