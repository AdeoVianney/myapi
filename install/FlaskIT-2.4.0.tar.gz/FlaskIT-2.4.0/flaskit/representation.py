# Flask lib
from flask import current_app, g
from flask import make_response

# Flaskit imports
from flaskit import app
from flaskit.utils import ErrorInternal

# Standards lib
import json
import ujson


@app.api.representation('text/plain')
def output_text(data, code, headers=None):
    message = ""

    if "_metadata" in data and "status" in data["_metadata"]:
        message += "status:%s\n" % (data["_metadata"]["status"])
    elif "status" in g:
        message += "status:%s\n" % g.status
    else:
        message += "status:2\n"

    if "_metadata" in data and "count" in data["_metadata"]:
        message += "count:%s\n" % (data["_metadata"]["count"])

    if "_metadata" in data and "message" in data["_metadata"]:
        message += data["_metadata"]["message"] + "\n"
    elif "message" in g:
        message += g.message + "\n"
    else:
        message += "Unknown\n"

    message += json.dumps(data)

    resp = make_response(message, code)
    return resp
    resp.headers.extend(headers or {})


# override output json
# from : flask_restful/representations/json.py
@app.api.representation('application/json')
def output_json(data, code, headers=None):
    """Makes a Flask response with a JSON encoded body"""

    settings = {}

    # If we're in debug mode, and the indent is not set, we set it to a
    # reasonable value here.  Note that this won't override any existing value
    # that was set.  We also set the "sort_keys" value.
    local_settings = settings.copy()
    if current_app.debug:
        local_settings.setdefault('indent', 4)
        local_settings.setdefault('sort_keys', True)

    # no space
    local_settings.setdefault('separators', (',', ':'))

    # We also add a trailing newline to the dumped JSON if the indent value is
    # set - this makes using `curl` on the command line much nicer.
    try:
        if current_app.debug:
            dumped = json.dumps(data, **local_settings)
            if 'indent' in local_settings:
                dumped += '\n'
        else:
            # faster lib (but without indent support)
            dumped = ujson.dumps(data)

    except Exception, e:
        ErrorInternal(message=e)

    resp = make_response(dumped, code)
    resp.headers.extend(headers or {})
    return resp
