# Flask imports
from flask import g

# Flaskit imports
from flaskit import app
from flaskit.logger import loglevels

# Python imports
import json
import re
#import xmltodict
#import datetime
#import fnmatch


####################################################
# ACL Exception
# use when matching acl is found
####################################################
class ACLException(Exception):
    def __init__(self, action, message, options={}):
        self.action = action
        self.message = message
        self.options = options


####################################################
# AuthAcl_API
# Abstract class for API authorization
# Need to be redefined by derivated class
####################################################
class AuthAcl_API:
    # abstract method to be redefined
    def verify(self, obj, acl):
        raise Exception("No class defined for this API : %s" % g.apiname)

    # check all attr against their method to identify matching rules
    def checkAllowed(self, obj, acl, allowed, AAA):

        # First, make a copy of all specific attributes to check
        acl2 = acl.copy()
        if "@action" in acl2:
            del acl2["@action"]
        if "@enabled" in acl2:
            del acl2["@enabled"]
        if "@options" in acl2:
            del acl2["@options"]

        # empty attributes are not considered
        for attr in acl2.keys():
            if acl2[attr] == "": del acl2[attr]

        regexp = re.compile("^(?P<prefix>@?)(?P<attr>\w+?)(?P<op>_not|_re|_not_re|)$")

        # Second, check if combinaison of args are allowed, given a list of all allowed combinaisons
        # Deduplicate keys (without op suffix)
        acl2keys = acl2.keys()
        lst_attr = {}
        for item in acl2keys:
            m = regexp.search(str(item))
            if not m:
                raise Exception("Error : Invalid acl. No allowed attribute '%s' (%s)" % (item, json.dumps(acl)))
            lst_attr[m.group("attr")] = 1

        # search inside allowed combinaisons
        found = False
        if len(allowed) == 0:
            found = True

        for OPTS in allowed:
            diff1 = list(set(OPTS) - set(lst_attr))
            diff2 = list(set(lst_attr) - set(OPTS))
            if len(diff1) == 0 and len(diff2) == 0:
                found = True
                break

        # combinaison not found : not allowed
        if not found:
            app.logger.info(acl2)
            raise Exception("Error : Invalid acl. No allowed combinaison %s (%s)" % (acl2keys, json.dumps(acl)))

        # Third, verify that all attributes are ok to declare that the rule match
        allres = []
        for key in acl2keys:
            if key[0] == "@":
                selector = key[1:]
            else:
                selector = key

            m = regexp.search(selector)
            if not m:
                raise Exception("Error : Invalid acl. No allowed attribute '%s' (%s)" % (selector, json.dumps(acl)))
            attr = m.group("attr")
            op = m.group("op")

            attr_ori = attr + op

            try:
                # Is there a method with the name of attribute ?
                if hasattr(AAA, attr_ori):
                    # call specific attribute verification method
                    result = getattr(AAA, attr_ori)()

                else:
                    if not hasattr(AAA, "get_" + attr):
                        app.logger.error("Error : Internal error. Missing method 'get_%s'" % attr)
                        raise Exception("Missing method 'get_%s'" % attr)

                    # get attribute value
                    value = getattr(AAA, "get_" + attr)()

                    # missing field : no need to go further with this acl
                    if value is None:
                        return

                    # call generic attribute verification method
                    if op == "":
                        result = AAA.field_equal(attr, value, key)
                    elif op == "_not":
                        result = AAA.field_not_equal(attr, value, key)
                    elif op == "_re":
                        result = AAA.field_match_re(attr, value, key)
                    elif op == "_not_re":
                        result = AAA.field_not_match_re(attr, value, key)
                    else:
                        # this should never be executed
                        raise Exception("Invalid op code '%s' for attr '%s'" % (op, attr))

            except Exception, e:
                app.logger.exception(e)
                raise Exception("Error : Internal error on acl '%s' (%s)" % (attr, json.dumps(acl)))

            # no match : no need to go further with this acl
            if result is None:
                return

            # store message for logs
            allres.append(result["msg"])

        # found matching rule
        if len(acl2keys) == len(allres):
            raise ACLException(acl["@action"], " && ".join(allres))  # allow or deny

        # no match
        return


####################################################
# AuthAclAttrGeneric
# Abstract class for API authorization
# Need to be redefined by derivated class
####################################################
class AuthAclAttrGeneric:
    def __init__(self, obj, acl):
        self.obj = obj
        self.acl = acl

    # filter : remote_ip
    def remote_ip(self):
        app.logger.log(loglevels["DEBUG2"], "Remote host name identifed : %s" % g.remote_host)
        for host in g.remote_host:
            if self.acl["@remote_ip"] == host:
                msg = "@remote_ip match '%s'" % host
                return {"msg": msg}

        return

    # filter : remote_ip_re
    def remote_ip_re(self):
        app.logger.log(loglevels["DEBUG2"], "Remote host name identifed : %s" % g.remote_host)
        for host in g.remote_host:
            try:
                result = re.search(self.acl["@remote_ip_re"], host)
            except Exception:
                raise Exception("Error : Invalid regexp for acl : %s" % (json.dumps(self.acl)))
            if result:
                msg = "remote host '%s' =~ @remote_ip_re '%s'" % (host, self.acl["@remote_ip_re"])
                return {"msg": msg}

        return

    # filter field : equal
    def field_equal(self, name, value, key):
        if value == self.acl[key]:
            msg = "%s '%s' == %s" % (name, value, key)
            return {"msg": msg}

        return

    # filter field : not equal
    def field_not_equal(self, name, value, key):
        if value != self.acl[key]:
            msg = "%s '%s' != %s" % (name, value, key)
            return {"msg": msg}

        return

    # filter field : match regexp
    def field_match_re(self, name, value, key):
        try:
            result = re.search(self.acl[key], value)
        except Exception:
            raise Exception("Error : Invalid regexp for acl : %s" % json.dumps(self.acl))
        if result:
            msg = "%s '%s' =~ %s '%s'" % (name, value, key, self.acl[key])
            return {"msg": msg}

        return

    # filter field : not match regexp
    def field_not_match_re(self, name, value, key):
        try:
            result = re.search(self.acl[key], value)
        except Exception:
            raise Exception("Error : Invalid regexp for acl : %s" % json.dumps(self.acl))
        if not result:
            msg = "%s '%s' !~ %s '%s'" % (name, value, key, self.acl[key])
            return {"msg": msg}

        return
