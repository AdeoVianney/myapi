# Flaskit imports
from flaskit import app
from flaskit.cache import gGet, gSet
from flaskit.json_comment import load_json
from flaskit.dynrules import DynRules

# Python imports
import glob
import socket
from jinja2 import Template


class Config:

    def check(self):

        mandatory = ["API_NAME", "API_VERSION", "API_DESCRIPTION", "PREFIX_URL"]

        default = {
            "API_DIRNAME":                      "{% print API_NAME[4:] + '_api' %}",
            "BASE_PATH":                        "https://{{FQDN}}:{{HTTPSRV_PORT}}",
            "BASE_URL":                         "{{PREFIX_URL}}",
            "SPEC_URL":                         "{{PREFIX_URL}}/spec",
            "TEST_BASE_PATH":                   "http://{{FQDN}}:{{TEST_HTTPSRV_PORT}}",
            "TEST_BASE_URL":                    "{{PREFIX_URL}}",
            "TEST_SPEC_URL":                    "{{PREFIX_URL}}/spec",
            "PREFIX_LOG_DIR":                   "/home3/{{API_NAME}}",
            "TEST_PREFIX_LOG_DIR":              ".",
            "PREFIX_CACHE_DIR":                 "/home3/{{API_NAME}}",
            "TEST_PREFIX_CACHE_DIR":            ".",
            "AUTHORIZATION_CONFIG_DIR":         "./conf/auth.d",
            "AUTHENTICATION_CONFIG_DIR":        "./conf/users.d",
            "DYNRULES_CONFIG_DIR":              "./conf/dynrules.d",
            "LOG_LEVEL":                        "INFO",
            "DEFAULT_AUTHENTICATION":           True,
            "CURL_SAMPLE":                      "curl -kv \"{{BASE_PATH}}{{BASE_URL}}",
            "TEST_CURL_SAMPLE":                 "curl -kv \"{{TEST_BASE_PATH}}{{TEST_BASE_URL}}",
            "MAIN_LOG_FILE":                    "{{PREFIX_LOG_DIR}}/log/api.log",
            "AUDIT_LOG_FILE":                   "{{PREFIX_LOG_DIR}}/log/audit.log",
            "AUDIT_LOG_DIR":                    "{{PREFIX_LOG_DIR}}/log/audit",
            "ERROR_LOG_FILE":                   "{{PREFIX_LOG_DIR}}/log/error.log",
            "STATS_LOG_FILE":                   "{{PREFIX_LOG_DIR}}/log/stats.log",
            "GENERATED_DOC_DIR":                "./doc",
            "DEBUG":                            0,
            "TEST_HTTPSRV_HOST":                "0.0.0.0",
            "TEST_HTTPSRV_PORT":                5000,
            "HTTPSRV_PORT":                     8443,
            "LOGROTATE_NB_KEEP":                7,
            "CACHE_TYPE":                       "filesystem",
            "CACHE_RESET":                      False,
            "CACHE_DIR":                        "{{PREFIX_CACHE_DIR}}/flaskcache",
            "CACHE_DEFAULT_TIMEOUT":            922337203685477580,
            "CACHE_THRESHOLD":                  922337203685477580,
            "CACHE_TIMEOUT_API_FUNCTION":       30,
            "CACHE_TIMEOUT_DB_AUTHORIZATION":   60,
            "CACHE_TIMEOUT_DB_AUTHENTICATION":  60,
            "CACHE_TIMEOUT_DB_DYNRULES":        20,
            "CACHE_TIMEOUT_CONFIG_API":         60,
            "CACHE_TIMEOUT_CONFIG_GENERAL":     60,
            "CORS_ALLOW_ORIGIN":                "*",
            "CORS_ALLOW_METHODS":               "GET, POST, PUT, DELETE",
            "CORS_ALLOW_HEADERS":               "Authorization, Content-Type, X-AuthToken",
            "STATSD_HOST":                      "localhost",
            "STATSD_PORT":                      8135,
        }


        for name in mandatory:
            if name not in app.config:
                raise Exception("Unable to find mandatory param '%s' in configuration file %s" % (name, app.config["CONFIG_FILE"]))

        for name in default:
            if name not in app.config:
                app.config[name] = default[name]

    def templatize(self):

        # templatize config (jinja2 format) (2 pass for embeeded vars)
        for i in range(0,2):
            config = {}
            for name in app.config:
                config[name] = str(app.config[name])
                config["FQDN"] = socket.getfqdn()
            for name in app.config:
                if type(app.config[name]) in (str, unicode):
                    template = Template(str(config[name]))
                    app.config[name] = template.render(config)

    def readAllConfigs(self):

        self.readGeneralConfig()

        # Read routes definitions and store it in global (no expiration)
        routes = self.readRoutes()
        gSet("config.routes", routes)

        # Read apis definitions and store it in global (no expiration)
        apis = self.readAPIs()
        gSet("config.apis", apis)

        DynRules().reloadDB()

    def readGeneralConfig(self):

        # Backup default debug mode (for dynamic activation per request)
        if "DEBUG" in app.config:
            app.config["DEFAULT_DEBUG"] = app.config["DEBUG"]
        else:
            app.config["DEFAULT_DEBUG"] = False

    def updateGeneralConfig(self):

        # Load config (with expiration)
        config = gGet("config.flask")
        if config is None:
            #app.logger.debug("Reload main config")
            # create alternate flask config object (see flask/app.py)
            config = app.make_config(False)
            config.from_pyfile(app.config["CONFIG_FILE"])
            gSet("config.flask", config, timeout=app.config["CACHE_TIMEOUT_CONFIG_GENERAL"])

            # dynamic update some vars 
            if "DEBUG" in config:
                app.config["DEFAULT_DEBUG"] = config["DEBUG"]
            if "LOG_LEVEL" in config:
                app.config["LOG_LEVEL"] = config["LOG_LEVEL"]

    def readRoutes(self):
        config = []
        params = ["enabled", "description", "class", "endpoint", "url"]
        for filename in glob.glob("%s/%s" % (app.config["LOCAL_DIR"], "def/routes/*.json")):
            try:
                str = open(filename).read()
                data = load_json(str)  # uncomment json file before processing
            except Exception, e:
                message = "Error : Unable to load json routes from file '%s' (%s). Skip it" % (filename, e)
                app.logger.exception(e)
                raise Exception(message)

            data2 = []
            for d in data:
                # verify definition
                for p in params:
                    if p not in d:
                        raise Exception("Unable to find param '%s' in route definition (%s)" % (p, filename))

                if not d["enabled"]:
                    continue
                data2.append(d)

            config.extend(data2)

        return config

    def readAPIs(self):
        # Read APIs definitions
        config = {}
        for filename in glob.glob("%s/%s" % (app.config["LOCAL_DIR"], "def/apis/*.json")):
            data = self.readAPI(filename=filename)

            # Load all APIs (even disabled one, as class initialization need definition (ex : authentication decorator)) 
            # -> disabling at runtime
            # if "enabled" not in data or data["enabled"] == False:
            #    continue

            config[data["name"]] = data

        return config

    def readAPI(self, apiname=None, filename=None):

        # identify filename
        if filename is None:
            dir = "%s/%s" % (app.config["LOCAL_DIR"], "def/apis")
            filename = "%s/%s%s" % (dir, apiname, ".json")

        # Read API definition
        try:
            str = open(filename).read()
            data = load_json(str)  # uncomment json file before processing
        except Exception, e:
            message = "Error : Unable to load json schema from file '%s' (%s). Skip it" % (filename, e)
            app.logger.exception(e)
            raise Exception(message)

        mandatory = []

        default = {
            "authorizationCheckAcls":                      True,   # check ACLs during authorize
        }

        for name in mandatory:
            if name not in data:
                raise Exception("Unable to find mandatory param '%s' in api file %s" % (name, filename))

        for name in default:
            if name not in data:
                data[name] = default[name]

        # Force debug parameter on each api
        if "debug" not in data["args"]:
            data["args"]["debug"] = {
                "description": "Debug flag",
                "dataType": "string",
                "regexp": "^(0|1|2|)$",
                "location": "args",
                "required": False,
            }
        # Force nocache parameter on each api (usefull only on GET requests)
        if "cache" in data and data["cache"] != 0:
            if "nocache" not in data["args"]:
                data["args"]["nocache"] = {
                    "description": "No cache flag (disable caching) (Values:true,True,1,false,False,0)",
                    "dataType": "boolean",
                    "location": "args",
                    "required": False,
                }

        # Force dryrun parameter on each api (usefull only on GET requests)
        if "dryrun" in data and data["dryrun"] == True and "dryrun" not in data["args"]:
            data["args"]["dryrun"] = {
                "description": "dryrun flag (simulation mode) (Values:true,True,1,false,False,0)",
                "dataType": "boolean",
                "location": "args",
                "required": False,
            }

        return data
