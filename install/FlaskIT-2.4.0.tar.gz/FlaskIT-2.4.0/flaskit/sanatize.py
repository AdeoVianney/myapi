# Flask imports
from flask import request, g
import flask_restful as restful
from flask_restful import inputs
from flaskit.cache import gGet, gSet
from werkzeug.exceptions import BadRequest

# Flaskit imports
from flaskit import app

# Python imports
import re
import json
import jsonschema


# Extend default json schema validator to support 'default' param
# tryied also with seep lib, but the json return is broken
# https://python-jsonschema.readthedocs.org/en/latest/faq/
def extend_with_default(validator_class):
    validate_properties = validator_class.VALIDATORS["properties"]

    def set_defaults(validator, properties, instance, schema):
        for error in validate_properties(
                validator, properties, instance, schema,
        ):
            yield error

        for property, subschema in properties.iteritems():
            if "default" in subschema:
                instance.setdefault(property, subschema["default"])

            # extend native regexp support (to extend limited schema regexp)
            # but it seems that pyhton jsonschema is able to manage extended regexp, so this tag could be useless
            # http://spacetelescope.github.io/understanding-json-schema/reference/regular_expressions.html
            if "_altPattern" in subschema and property in instance:
                try:
                    regexp = re.compile(subschema["_altPattern"])
                except Exception:
                    # bas regexp
                    raise Exception("Invalid _altPattern '%s'" % (subschema["_altPattern"]))
                m = regexp.search(str(instance[property]))
                if not m:
                    raise Exception("'%s' does not match _altPattern '%s' (%s)" %
                                    (instance[property], subschema["_altPattern"], property))

    return jsonschema.validators.extend(
            validator_class, {"properties": set_defaults},
    )


extended_jsonschema = extend_with_default(jsonschema.Draft4Validator)


###########################################################################
# Class that verify request parameters syntax
###########################################################################
class Sanatize:
    #def schema(self):
    #    json_data = open(file_directory).read()
    #
    #    data = json.loads(json_data)

    def raw_type(self, value):
        return value

    def schema_validate(self, data, schema):

        try:
            # jsonschema.validate(data, schema)
            extended_jsonschema(schema).validate(data)
        except Exception, e:
            app.logger.warning(e)
            message = "Error : Unable to validate body"

            # regexp error
            m1 = re.search(r"u'(.*)' does not match", str(e), re.MULTILINE)
            if m1:
                m2 = re.search(r"On instance(.*?):", str(e), re.MULTILINE)
                m3 = re.search(r"u'pattern': u'(.*?)'", str(e), re.MULTILINE)
                m4 = re.search(r"u'description': u'(.*?)'", str(e), re.MULTILINE)
                if m2 and m3:
                    data = {
                        "message": "%s (regexp matching)" % message,
                        "value": m1.group(1),
                        "field": m2.group(1),
                        "regexp": m3.group(1),
                    }
                    if m4:
                        data["description"] = m4.group(1)
                    raise ValueError(data)

            # type error
            m1 = re.search(r"(.*) is not of type u'(.*?)'", str(e), re.MULTILINE)
            if m1:
                m2 = re.search(r"On instance(.*?):", str(e), re.MULTILINE)
                m3 = re.search(r"u'description': u'(.*?)'", str(e), re.MULTILINE)
                if m2:
                    data = {
                        "message": "%s (wrong type %s)" % (message, m1.group(2)),
                        "value": m1.group(1),
                        "field": m2.group(1),
                    }
                    if m3:
                        data["description"] = m3.group(1)
                    raise ValueError(data)

            # enum error
            m1 = re.search(r"(.*) is not one of (.*)", str(e), re.MULTILINE)
            if m1:
                m2 = re.search(r"On instance(.*?):", str(e), re.MULTILINE)
                m3 = re.search(r"u'description': u'(.*?)'", str(e), re.MULTILINE)
                if m2:
                    data = {
                        "message": "%s ('%s' does not match enum %s)" % (message, m1.group(1), m1.group(2)),
                        "value": m1.group(1),
                        "field": m2.group(1),
                        "enum": m1.group(2),
                    }
                    if m3:
                        data["description"] = m3.group(1)
                    raise ValueError(data)

            # default
            s = str(e).split('\n', 1)[0]
            message = "%s : %s" % (message, s)
            raise ValueError(message)

    def get(self, args):

        filter = g.API["args"]

        #    # Add general options for every request
        #    filter["debug"] = { "regexp":   "^(0|1|2|)$",
        #                        "location": "args",
        #                      }
        #    filter["nocache"] = { "regexp":   "^(true|false|)$",
        #                          "location": "args",
        #                        }
        #    if "dryrun" in g.API and g.API["dryrun"] == True:
        #        filter["dryrun"] = { "regexp":   "^(true|false|)$",
        #                             "location": "args",
        #                           }

        # init RequestParser
        parser = restful.reqparse.RequestParser()
        for arg in filter:

            if "location" not in filter[arg]:
                raise Exception("Error : invalid sanitization structure (missing location for arg %s)" % arg)
            if "dataType" not in filter[arg]:
                raise Exception("Error : invalid sanitization structure (missing location for arg %s)" % arg)

            kwargs = {}
            if filter[arg]["dataType"] == "string":
                pass
            elif filter[arg]["dataType"] == "boolean":
                kwargs["type"] = inputs.boolean
            elif filter[arg]["dataType"] == "integer":
                kwargs["type"] = inputs._get_integer
            else:
                raise Exception("Error : invalid sanitization structure (unknown dataType : %s)" % filter[arg]["dataType"])

            # uri is exclude as not reconized by reqparse
            if filter[arg]["location"] == "uri":
                if filter[arg]["required"] == True and arg not in args:
                    raise ValueError("Error : required arg not found in uri '%s'" % arg)
                continue
            elif filter[arg]["location"] == "args":  # query string
                parser.add_argument(arg, location="args", **kwargs)
            elif filter[arg]["location"] == "header":
                parser.add_argument(arg, location="headers", **kwargs)
            elif filter[arg]["location"] == "body":
                # data in 1st level of json structure can be analyzed directly without jsonschema
                if filter[arg]["bodyType"] == "json":  # json data as unicode string
                    parser.add_argument(arg, **kwargs)

                # data in 2nd+ level of json structure must be analyzed with jsonschema
                elif filter[arg]["bodyType"][0:11] == "jsonschema:":  # json data as an object : use json schema (from this level)
                    kwargs["type"] = self.raw_type
                    parser.add_argument(arg, **kwargs)
                    filter[arg]["bodyObject"] = filter[arg]["bodyType"][11:]
            else:
                #parser.add_argument(arg, location=filter[arg]["location"])
                raise Exception("Error : invalid sanitization structure (unknown location : %s)" % filter[arg]["location"])
        try:
            args2 = parser.parse_args()
        except BadRequest, e:
            raise ValueError("Error : Unable to parse args - check args format type (%s)" % e)
        except Exception, e:
            app.logger.exception(e)
            raise ValueError("Error : Unable to parse args (%s)" % e)

        # extras parsing (not processed from parser object)
        for arg in filter:
            if filter[arg]["location"] == "args":
                if "default" in filter[arg] and (arg not in args2 or args2[arg] is None):
                    args2[arg] = filter[arg]["default"]

                # validate data with custom regexp (allow to escape \\ as this is not possible inside json)
                if "_altRegexp" in filter[arg]:
                    _altRegexp = filter[arg]["_altRegexp"].replace("\\\\", "\\")
                    try:
                        regexp = re.compile(_altRegexp)
                    except Exception:
                        raise Exception("Error : Invalid regexp for arg '%s' : %s" % (arg, _altRegexp))

                    if not regexp.search(str(args2[arg])):
                        raise ValueError("Error : argument '%s' does not match allowed values : %s" % (arg, _altRegexp))

        # Concatenate parameters
        for arg in args:
            args2[arg] = args[arg]

        # search for extra args not defined (flask does not manage them)
        for arg in request.args:
            if arg not in filter:
                raise ValueError("Error : unknown argument '%s' is not sanitized" % arg)

        # Validate each parameter with regexp
        for arg in args2:
            if arg not in filter:
                raise ValueError("Error : argument '%s' is not sanitized" % arg)

            if args2[arg] is None:
                if "required" in filter[arg] and filter[arg]["required"] == True:
                    raise ValueError("Error : required arg not found '%s'" % arg)
                continue

            # validate data with json schema
            if "bodyObject" in filter[arg]:
                try:
                    dir = "%s/%s" % (app.config["LOCAL_DIR"], "def/schemas")
                    schema_filename = "%s/%s.schema.json" % (dir, filter[arg]["bodyObject"])
                    schema_str = open(schema_filename).read()
                    schema = json.loads(schema_str)
                except Exception, e:
                    app.logger.warning(e)
                    raise Exception("Error : Unable to load json schema from file '%s' (%s)" % (schema_filename, e))
                try:
                    extended_jsonschema(schema).validate(args2[arg])
                except Exception, e:
                    app.logger.warning(e)
                    s = str(e).split('\n', 1)[0]
                    raise ValueError("Error : Unable to validate parameters '%s' on schema : %s" % (arg, s))

            # validate data with regexp
            if "regexp" in filter[arg]:
                try:
                    regexp = re.compile(filter[arg]["regexp"])
                except Exception:
                    raise Exception("Error : Invalid regexp for arg '%s' : %s" % (arg, filter[arg]["regexp"]))

                if not regexp.search(str(args2[arg])):
                    raise ValueError(
                        "Error : argument '%s' does not match allowed values : %s (%s)" % (arg, filter[arg]["regexp"], str(args2[arg])))

        # Process body with full json schema
        if "body" in g.API:
            if 'bodyType' in g.API["body"]:
                if g.API["body"]["bodyType"][0:11] == "jsonschema:":  # json data as an object : use json schema

                    # Try to get key from cache (generated during documentation)
                    key = "%s-Request" % g.API["body"]["bodyType"][11:]
                    g.schema_body = gGet(key)
                    if g.schema_body is None:
                        # this could occurs when the schema file is missing or when no class pointing on the schema is declared
                        raise Exception("Unable to load schema from cache (%s). Missing schema (%s) or missing class declaration that use this schema" % (key, g.API["body"]["bodyType"][11:]))

                    if g.data is None or len(g.data) == 0:
                        raise ValueError("Error : empty body")

                    try:
                        # request has been altered (ex : dynrule)
                        #if g.request_tainted:
                        #    g.body_json = json.loads(g.data)
                        #else:
                        #    g.body_json = request.get_json()

                        # do no longer use native request.get_json method, as we want to control charset
                        # sometimes, input data are not in utf8 (ex : latin1) : wa had to convert them before
                        g.data = g.data.decode("utf-8", "replace")
                        g.body_json = json.loads(g.data)

                    except Exception, e:
                        app.logger.exception(e)
                        app.logger.warning(e)
                        s = str(e).split('\n', 1)[0]
                        raise ValueError("Error : Unable to load json from body : %s" % s)

                    if g.body_json is None:
                        raise ValueError("Error : no json data")

                    # validate body against schema
                    self.schema_validate(g.body_json, g.schema_body)

                    # copy all body parameters
                    for arg in g.body_json:
                        if arg in args2:
                            raise ValueError("Error : parameter '%s' defined both in body and query" % arg)
                        args2[arg] = g.body_json[arg]
                else:
                    raise ValueError("Error : Unable to validate body")
            else:
                # no bodyType : json without schema
                if g.data is None or len(g.data) == 0:
                    raise ValueError("Error : empty body")

                try:
                    # request has been altered (ex : dynrule)
                    if g.request_tainted:
                        g.body_json = json.loads(g.data)
                    else:
                        g.body_json = request.get_json()
                except Exception, e:
                    app.logger.warning(e)
                    s = str(e).split('\n', 1)[0]
                    raise ValueError("Error : Unable to load json from body : %s" % s)

                if g.body_json is None:
                    raise ValueError("Error : no json data")

                # copy all body parameters
                for arg in g.body_json:
                    if arg in args2:
                        raise ValueError("Error : parameter '%s' defined both in body and query" % arg)
                    args2[arg] = g.body_json[arg]

        return args2
