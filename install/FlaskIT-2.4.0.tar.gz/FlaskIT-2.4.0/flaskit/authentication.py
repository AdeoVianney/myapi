# Flask imports
from flask import request, g, session
from flask.ext.httpauth import HTTPBasicAuth

# Flaskit imports
from flaskit import app
from flaskit.utils import ErrorAuthNeed, ErrorAuth, ErrorInternal
from flaskit.cache import gGet, gSet

# Python imports
import hashlib
import glob

auth = HTTPBasicAuth()


###########################################################################
# handler for verify user/password at each request
###########################################################################
@auth.verify_password
def verify_password(username, password):
    # Verify user/password
    valid = authenticate().verify(username, password)
    return valid


###########################################################################
# handler for failed verification
###########################################################################
@auth.error_handler
def unauthenticated():
    app.logger.warning("Unauthenticated access")
    ErrorAuthNeed("Unauthenticated access")


class LDAPauth:
    def login_required(self):
        if 'username' not in session:
            app.logger.warning("Unauthenticated access")
            ErrorAuth("Unauthenticated access")


###########################################################################
# Class uthentication logic
###########################################################################
class authenticate:
    # Read users database
    def loadDB(self):
        users = {}

        try:
            if app.config["AUTHENTICATION_CONFIG_DIR"][0] == "/":
                users_dir = app.config["AUTHENTICATION_CONFIG_DIR"]
            else:
                users_dir = "%s/%s" % (app.config["LOCAL_DIR"], app.config["AUTHENTICATION_CONFIG_DIR"])
        except Exception, e:
            app.logger.error("Unable to define users db dir (%s)" % e)
            ErrorInternal("Users database error")

        try:
            for users_filename in glob.glob("%s/*.cfg" % users_dir):
                lines = [line.strip() for line in open(users_filename)]

                for line in lines:
                    stp = line.split(':')
                    if len(stp) != 2:
                        continue
                    if stp[0] == "":
                        continue
                    if stp[0][0] == "#":
                        continue
                    if stp[0] in users:
                        app.logger.error("Redefined user in db (%s). Skip it" % stp[0])

                    users[stp[0]] = stp[1]

        except Exception, e:
            app.logger.error("Unable to read users db (%s)" % e)
            ErrorInternal("Users database error")

        return users

    # verify uiser/password
    def verify(self, username, password):

        # Load DB (with expiration)
        self.db = gGet("authentication.db")
        if self.db is None:
            app.logger.debug("Reload authentication DB")
            self.db = self.loadDB()
            gSet("authentication.db", self.db, timeout=app.config["CACHE_TIMEOUT_DB_AUTHENTICATION"])

        if username in self.db.keys():
            hash_object = hashlib.sha1(password)
            hex_dig = hash_object.hexdigest()
            if hex_dig == self.db[username]:
                return True

        return False
