
def buildSwaggerArgs(infos):
    args = {}

    args["notes"] = infos["description"].encode('ascii', 'replace')
    args["nickname"] = infos["name"].encode('ascii', 'replace')

    params = []
    for arg in infos["args"]:
        if infos["args"][arg]["location"] == "body":
            continue

        param = {}
        param["name"] = arg
        param["description"] = infos["args"][arg]["description"]
        if "regexp" in infos["args"][arg]:
            param["description"] += ("<br/><br/><u>Validation regexp</u> : <pre>%s</pre>" %
                                     (infos["args"][arg]["regexp"]))

        param["required"] = infos["args"][arg]["required"]

        if infos["args"][arg]["dataType"] == "object":
            param["dataType"] = _MetadataOperationFields.__name__
        else:
            param["dataType"] = infos["args"][arg]["dataType"]

        if infos["args"][arg]["location"] == "uri":
            param["paramType"] = "path"
        elif infos["args"][arg]["location"] == "args":
            param["paramType"] = "query"
        elif infos["args"][arg]["location"] == "header":
            param["paramType"] = "header"
        else:
            param["paramType"] = infos["args"][arg]["location"]

        params.append(param)
    args["parameters"] = params

    # create root body structure (could be nested after)
    if "swaggerBodyClass" in infos:
        param = {}
        param["paramType"] = "body"
        param["dataType"] = infos["swaggerBodyClass"]
        param["required"] = True
        param["name"] = "body"
        param["description"] = "%s object in body" % infos["swaggerBodyClass"]
        args["parameters"].append(param)

    if "swaggerResponseClass" in infos:
        args["responseClass"] = infos["swaggerResponseClass"].encode('ascii', 'replace')

    if "swaggerResponseMessages" in infos:
        args["responseMessages"] = infos["swaggerResponseMessages"]

    return args


class buildSwagger:
    def getNotes(self, infos):
        return infos["description"].encode('ascii', 'replace')

    def getNickName(self, infos):
        return infos["name"].encode('ascii', 'replace')

    def getParameters(self, infos):
        params = []
        for arg in infos["args"]:
            param = {}
            param["name"] = arg
            param["description"] = infos["args"][arg]["description"]
            if "regexp" in infos["args"][arg]:
                param["description"] += ("<br/><br/><u>Validation regexp</u> : <pre>%s</pre>" %
                                         (infos["args"][arg]["regexp"]))

            param["required"] = infos["args"][arg]["required"]

            if infos["args"][arg]["dataType"] == "object":
                param["dataType"] = _MetadataOperationFields.__name__
            else:
                param["dataType"] = infos["args"][arg]["dataType"]

            if infos["args"][arg]["location"] == "uri":
                param["paramType"] = "path"
            elif infos["args"][arg]["location"] == "args":
                param["paramType"] = "query"
            else:
                param["paramType"] = infos["args"][arg]["location"]

            params.append(param)
        return params

    def getResponseMessages(self, infos):
        if "swaggerResponseMessages" not in infos:
            return None
        return infos["swaggerResponseMessages"]

    def getResponseClass(self, infos):
        if "swaggerResponseClass" not in infos:
            return None
        return infos["swaggerResponseClass"].encode('ascii', 'replace')
