from flask import g
import flask_restful as restful

try:
    # noinspection PyUnresolvedReferences
    from collections import OrderedDict
except ImportError:
    from ordereddict import OrderedDict


def isTrue(val):
    if val is None:
        return False
    if val == "false":
        return False
    return True


def ErrorInternal(message=None, status=2, data=None, httpCode=500):
    g.response_status = status

    if message is not None:
        g.response_message = "Internal Error (%s) [uuid:%s]" % (message, g.uuid)
    else:
        g.response_message = "Internal Error [uuid:%s]" % g.uuid
    # stack_str = ''.join(traceback.format_stack())
    # restful.abort(500, _metadata = { "status":status, "message":"%s" % message, "backtrace":stack_str })
    _metadata = {"status": status, "message": "%s" % g.response_message, "uuid": g.uuid}
    if data is not None:
        _metadata["data"] = data
    restful.abort(httpCode, _metadata=_metadata)


def ErrorParams(message, status=2, data=None):
    g.response_status = status
    message = "%s [uuid:%s]" % (message, g.uuid)
    g.response_message = message
    _metadata = {"status": status, "message": "%s" % message, "uuid": g.uuid}
    if data is not None:
        _metadata["data"] = data
    restful.abort(400, _metadata=_metadata)


def ErrorAuth(message, status=2, data=None):
    g.response_status = status
    g.response_message = message
    _metadata = {"status": status, "message": "%s" % message, "uuid": g.uuid}
    if data is not None:
        _metadata["data"] = data
    restful.abort(403, _metadata=_metadata)


def ErrorAuthNeed(message, status=2, data=None):
    g.response_status = status
    g.response_message = message
    _metadata = {"status": status, "message": "%s" % message, "uuid": g.uuid}
    if data is not None:
        _metadata["data"] = data
    restful.abort(403, _metadata=_metadata)


def ErrorNotFound(message, status=2, data=None):
    g.response_status = status
    g.response_message = message
    _metadata = {"status": status, "message": "%s" % message, "uuid": g.uuid}
    if data is not None:
        _metadata["data"] = data
    restful.abort(404, _metadata = _metadata)


def ErrorDuplicate(message, status=2, data=None):
    g.response_status = status
    g.response_message = message
    _metadata = {"status": status, "message": "%s" % message, "uuid": g.uuid}
    if data is not None:
        _metadata["data"] = data
    restful.abort(409, _metadata=_metadata)


def ErrorNotAcceptable(message, status=2, data=None):
    g.response_status = status
    g.response_message = message
    _metadata = {"status": status, "message": "%s" % message, "uuid": g.uuid}
    if data is not None:
        _metadata["data"] = data
    restful.abort(406, _metadata=_metadata)

