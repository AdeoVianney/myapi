
from flaskit.authentication_lib import Authent
from flask import g

from flaskit.authorization import ACLException
# Flaskit imports
from flaskit import app
from flaskit.utils import *
from flaskit.logger import *
from flaskit.cache import *

# Python imports
import xmltodict
import datetime
import json
import fnmatch


####################################################
# Authorization
# Manage database and acl
####################################################
class TokenAuthent(Authent):
    def authenticate(self):
        self.InitAuth()

    def authorize(self, obj, abort=False, check_acls=True):
        return self.VerifyAuth(obj, abort, check_acls)

    def __init__(self):
        # Load DB (with expiration)
        Authent.__init__(self)
        self.db = gGet("authorization.db")
        if self.db is None:
            app.logger.debug("Reload authorization DB")
            self.db = self.loadDB()
            gSet("authorization.db", self.db, timeout=app.config["CACHE_TIMEOUT_DB_AUTHORIZATION"])

    def loadDB(self):
        # reload authorization configuration files
        try:
            if app.config["AUTHORIZATION_CONFIG_DIR"][0] == "/":
                auth_dir = app.config["AUTHORIZATION_CONFIG_DIR"]
            else:
                auth_dir = "%s/%s" % (app.config["LOCAL_DIR"], app.config["AUTHORIZATION_CONFIG_DIR"])
        except Exception, e:
            app.logger.error("Unable to define authorization db dir (%s)" % e)
            ErrorInternal("Authorization database error")

        # Rebuild dict with index on tokens and api
        auths = {}
        try:
            # reccursive glob *.xml
            matches = []
            for root, dirnames, filenames in os.walk(auth_dir):
                for filename in fnmatch.filter(filenames, '*.xml'):
                    matches.append(os.path.join(root, filename))

            for auth_filename in matches:
                content = open(auth_filename, "r").read()
                db = xmltodict.parse(content)

                if "@enabled" in db["auths"] and db["auths"]["@enabled"] == "0":
                    continue

                if not isinstance(db["auths"]["auth"], list):
                    db["auths"]["auth"] = [db["auths"]["auth"]]

                # create api array of dict
                for auth in db["auths"]["auth"]:

                    if "@family" not in auth:
                        auth["@family"] = "default"

                    if not isinstance(auth["api"], list):
                        auth["api"] = [auth["api"]]
                    api_t = {}
                    for api in auth["api"]:
                        if api["@name"] not in api_t:
                            api_t[api["@name"]] = []
                        api_t[api["@name"]].append(api)
                    auth["api"] = api_t

                    # create acl array if not
                    for api in auth["api"]:
                        for slot in range(len(auth["api"][api])):
                            if "acl" not in auth["api"][api][slot]:
                                continue
                            if not isinstance(auth["api"][api][slot]["acl"], list):
                                auth["api"][api][slot]["acl"] = [auth["api"][api][slot]["acl"]]

                    if auth["@token"] in auths:
                        app.logger.error("Redefined authorization token in db (%s). Skip it" % auth["@token"])

                    auths[auth["@token"]] = auth

        except Exception, e:
            app.logger.error("Unable to read authorization db files  (%s)" % e)
            ErrorInternal("Authorization database error")

        return auths

    ##############################################################################
    # Generic ACL verification
    # need to call specific class for the current API
    ##############################################################################
    def InitAuth(self):

        # verify current token
        if g.AuthToken is None:
            raise Exception("No authorization token provided")
        if g.AuthToken not in self.db:
            app.logger.error("Unknown authorization token : %s" % g.AuthToken)
            raise Exception("Unknown authorization token (uuid %s)" % g.uuid)

        # Load authorization datas for current token (if not yet done)
        if g.auth is None:
            g.auth = self.db[g.AuthToken]
            g.username = g.auth["@name"]
            g.userfamily = g.auth["@family"]

        # objects always as an array
        if "scope" in g.auth and not isinstance(g.auth["scope"]["objects"], list):
            g.auth["scope"]["objects"] = [g.auth["scope"]["objects"]]

    ##############################################################################
    # Generic ACL verification
    # need to call specific class for the current API
    ##############################################################################
    def VerifyAuth(self, obj, abort=False, check_acls=True):

        # use sub class for logging exceptions
        try:
            return self._VerifyAuth(obj, check_acls)
        except ACLException, e:
            app.logger.error(e.message)
            if abort:
                ErrorAuth(e.message)
            else:
                raise
        except Exception, e:
            # extended debug if there is an internal problem
            if type(e).__name__ != "Exception":
                app.logger.exception(e)
                ErrorInternal("Authorization module")

            app.logger.error(e)
            if abort:
                ErrorAuth(e)
            else:
                raise

    def _VerifyAuth(self, obj, check_acls):

        if g.auth["@enabled"] == "0":  # N/A
            raise Exception("Authorization token disabled (uuid %s)" % g.uuid)
        if g.auth["@expire"] != "":
            if datetime.datetime.now() > datetime.datetime.strptime(g.auth["@expire"], "%Y%m%d"):
                raise Exception("Authorization token expired (%s) (uuid %s)" % (g.auth["@expire"], g.uuid))

        if g.apiname not in g.auth["api"]:
            raise Exception("API '%s' forbidden for authorization token (uuid %s)" % (g.apiname, g.uuid))

        # compute APIKey options
        options = {}
        if "@options" in g.auth:
            for opt in g.auth["@options"].split(","):
                if opt.find("=") >= 0:
                    (key, val) = opt.split("=")
                    options[key] = val
                else:
                    options[opt] = 1

        # found ACLs. Loop over all slots
        for ACLS in g.auth["api"][g.apiname]:

            if "@id" in ACLS:
                id = ACLS["@id"]
            else:
                id = "undef"

            if "@enabled" in ACLS and ACLS["@enabled"] == "0":
                app.logger.debug(
                    "API '%s' disabled for this authorization token (uuid %s) (slot %s)" % (g.apiname, g.uuid, id))
                continue

            # compute ACL options
            if "@options" in ACLS:
                for opt in ACLS["@options"].split(","):
                    if opt.find("=") >= 0:
                        (key, val) = opt.split("=")
                        options[key] = val
                    else:
                        options[opt] = 1

            # do not evaluate any more object (usefull for global evaluation)
            if not check_acls:
                return options

            # Dynamic load of module/class to process ACLs (specified in API definition)
            if "authorizationClass" not in g.API:
                # if there is acl defined, it seems there is a missing config to evaluate rules
                # otherwise, just return
                if "acl" in ACLS:
                    app.logger.error("Found acl for token. Missing 'authorizationClass' definition for api '%s'" % g.apiname)
                    raise ImportError("Unable to load authz module")
                else:
                    return options

            # the following code can no longer be used automatically (must be manually called)
            # should be moved to another post-authorization system
            app.logger.log(loglevels["DEBUG2"], "Auth evaluation of obj '%s'" % obj)

            my_class = g.API["authorizationClass"].split("@")
            if len(my_class) != 2:
                app.logger.error(
                    "Bad 'authorizationClass' definition for api '%s' : %s" % (g.apiname, g.API["authorizationClass"]))
                raise ImportError("Unable to load authz module")
            try:
                module_name = my_class[0]
                class_name = my_class[1]
                module = __import__(module_name, fromlist=[class_name])
                klass = getattr(module, class_name)
            except ImportError, e:
                app.logger.error("Unable to import authz module %s:%s (%s)" % (module_name, class_name, e))
                raise ImportError("Unable to load authz module")
            except AttributeError, e:
                app.logger.error("Unable to import authz class %s:%s (%s)" % (module_name, class_name, e))
                raise ImportError("Unable to load authz class")
            except Exception, e:
                app.logger.exception(e)
                app.logger.error(
                    "Unable to import authz module/class %s:%s (%s:%s)" % (module_name, class_name, type(e), e))
                raise ImportError("Unable to load authz module/class")

            if "acl" in ACLS:
                # check each ACL
                for acl in ACLS["acl"]:
                    if "@enabled" in acl and acl["@enabled"] == "0":
                        continue

                    app.logger.log(loglevels["DEBUG2"],
                                   "Evaluation of acl (API:%s / Token:%s) : %s (slot %s)" %
                                   (g.apiname, g.AuthToken, json.dumps(acl), id))
                    try:
                        # call resource specific class to verify acl
                        klass().verify(obj, acl)

                    except ACLException, e:
                        # build complete options for this acl
                        options_t = options

                        # acl options
                        if "@options" in acl and acl["@options"] != "":
                            for opt in acl["@options"].split(","):
                                if opt.find("=") >= 0:
                                    (key, val) = opt.split("=")
                                    options_t[key] = val
                                else:
                                    options_t[opt] = 1

                        # add specific options for method
                        for opt in e.options:
                            options_t[opt] = e.options[opt]

                        if e.message != "":
                            app.logger.log(loglevels["DEBUG2"], "Acl matching. Result : %s" % e.message)

                        if e.action == "allow":
                            # got specific options if defined (replace general options)

                            # found allow : no more acl evaluations
                            app.logger.debug("Authorization allowed by acl (API:%s / Token:%s) : %s (slot %s)" %
                                             (g.apiname, g.AuthToken, json.dumps(acl), id))
                            return options_t

                        if e.action == "deny":
                            # do not evaluate others acl
                            # if "denyall" in options_t:
                            #    raise Exception("Authorization denied by acl (API:%s / Token:%s) : %s (slot %s)" %
                            #       (g.apiname, g.AuthToken, json.dumps(acl), id))

                            # found deny : no more acl evaluations
                            raise ACLException("deny",
                                               "Authorization denied by acl (API:%s) : %s (slot %s) (uuid %s)" %
                                               (g.apiname, json.dumps(acl), id, g.uuid), options_t)

                        # unknown action

                        raise Exception("Authorization denied by unknown action (%s) (API:%s) (slot %s) (uuid %s)" %
                                        (e.action, g.apiname, id, g.uuid))

                    except Exception, e:
                        app.logger.exception(e)
                        app.logger.error("Unable to execute auth verification : %s" % e)
                        raise Exception("Authorization denied (internal error) (uuid %s)" % g.uuid)

        # if no acl matching (or no acl)
        if "default" not in options or options["default"] == "deny":
            raise ACLException("deny", "Authorization denied by default (API:%s) (uuid %s)" % (g.apiname, g.uuid),
                               options)

        # default allow
        app.logger.debug("Authorization allowed by default (API:%s / Token:%s)" % (g.apiname, g.AuthToken))
        return options
