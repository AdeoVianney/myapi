# Flask imports
from flask import request, g, current_app
import flask_restful as restful
from flask_restful import Resource, fields, marshal_with, reqparse
from flask_restful_swagger import swagger
from werkzeug.exceptions import HTTPException

# Flaskit imports
from flaskit import app
from flaskit.sanatize import Sanatize
from flaskit.utils import ErrorInternal, ErrorAuth, ErrorParams
from flaskit.cache import gGet, gSet
from flaskit.config import Config
from flaskit.audit import Audit
from flaskit.stats import Stats
from flaskit.dynrules import DynRules
from flaskit.logger import logger_write_request, logger_write_response, logger_set_loglevel
from flaskit.swagger import buildSwagger, buildSwaggerArgs
from flaskit.authentication_lib import token_based, allow_all
from flaskit.lib.net import getAlias, getHost, getIPx

# Python imports
import os
import re
import json
from pprint import pprint, pformat
import traceback
from functools import wraps
import hashlib
import json
import thread
import time
import uuid
import pprint
import jinja2
import dpath


##############################################################################################
# decorator entry point (with args)
# This is a meta decorator that integrate call to others decorators based on conditional parameter
#   @auth.login_required  for authentication
#   @swagger.operation()  for swagger doc generation
##############################################################################################
def init_api(apiname, swaggerResponseClass=None):
    # print "Before defined arged decorated function"

    def decorator(f):
        # print "Before defined decorated function"

        # ***************************************
        # *** function pre-declaration step ***
        # ***************************************

        # Load apis definition
        APIs = gGet("config.apis")
        if apiname not in APIs:
            raise Exception("Invalid api '%s' (no description found)" % apiname)
        api = APIs[apiname]

        # Transform some docstrings to swaggerUI html (usefull for add some sample code)
        if "swagger" in api and api["swagger"] == True:
            __doc__ = []
            if f.__doc__ is None:
                f.__doc__ = ""
            for doc in f.__doc__.split("\n"):
                # Add title
                m = re.search(r'^\s*TITLE:(.*)', doc)
                if m:
                    doc = re.sub(r'\s*TITLE:(.*)', "<h4>%s</h4>" % (m.group(1)), doc)

                # add listing
                doc = re.sub(r'\s*<pre>', "<pre>", doc)
                doc = re.sub(r'\s*</pre>', "</pre>", doc)

                # add curl shortcut
                m = re.search(r'CURL:"(.*)', doc)
                if m:
                    sample = "%s%s" % (app.config["CURL_SAMPLE"], m.group(1))
                    if api["authentication"]:
                        sample = "%s -H \"X-AuthToken: <token>\"" % sample
                    if "body" in api:
                        sample = "%s -H \"Content-Type: application/json\"" % sample
                        if sample.find(" -d ") == -1 and sample.find(" --data ") == -1:
                            sample = "%s --data \"{<json request body>}\"" % sample
                    if f.__name__ == "get":
                        sample = "%s -X GET" % sample
                    if f.__name__ == "post":
                        sample = "%s -X POST" % sample
                    if f.__name__ == "put":
                        sample = "%s -X PUT" % sample
                    if f.__name__ == "patch":
                        sample = "%s -X PATCH" % sample
                    if f.__name__ == "delete":
                        sample = "%s -X DELETE" % sample
                    sample = sample.replace("<", "&lt;").replace(">", "&gt;")
                    doc = re.sub(r'\s*CURL:(.*)', sample, doc)

                __doc__.append(doc)
            f.__doc__ = "\n".join(__doc__)

            # remove newline
            f.__doc__ = f.__doc__.replace("<pre>\n", "<pre style='white-space: pre-wrap;'>")
            f.__doc__ = f.__doc__.replace("\n</pre>\n", "</pre>")
            f.__doc__ = f.__doc__.replace("\n<h4>", "<h4>")

        # ***************************************
        # *** function execution step ***
        # ***************************************

        # @auth.login_required
        # @swagger.operation()
        @wraps(f)
        def wrapped(*args, **kwargs):
            # print "Before running decorated function"

            g.apiname = apiname

            function = f

            # Load DB (with expiration)
            configapi = "config.api.%s" % apiname
            try:
                g.API = gGet(configapi)
            except Exception, e:
                app.logger.exception(e)
                app.logger.error("Cache seems to be corrupted. Regenerate")
                g.API = None
            if g.API is None:
                #app.logger.debug("Reload config api %s" % apiname)
                try:
                    g.API = Config().readAPI(apiname=apiname)
                except Exception:
                    message = "Invalid api '%s' (no description found)" % g.apiname
                    app.logger.error(message)
                    ErrorInternal("Invalid API")
                gSet(configapi, g.API, timeout=app.config["CACHE_TIMEOUT_CONFIG_API"])

            # some inits
            g.Audit = Audit()
            g.Stats = Stats()

            authent = "authentication" in g.API and g.API["authentication"]
            author = "authorization" in g.API and g.API["authorization"]

            if "authentClass" in g.API:
                my_class = g.API["authentClass"].split("@")
                if len(my_class) != 2:
                    app.logger.error(
                        "Bad 'authentClass' definition for api '%s' : %s" % (g.apiname, g.API["authentClass"]))
                    ErrorInternal("Unable to load authz module")
                try:
                    module_name = my_class[0]
                    class_name = my_class[1]
                    module = __import__(module_name, fromlist=[class_name])
                    klass = getattr(module, class_name)
                    g.Auth = klass()
                    #app.logger.debug("usage of authentication/authorization: %s:%s" % (module_name, class_name))
                except ImportError, e:
                    app.logger.error("Unable to import authz module %s:%s (%s)" % (module_name, class_name, e))
                    ErrorInternal("Unable to load authz module")
                except AttributeError, e:
                    app.logger.error("Unable to import authz class %s:%s (%s)" % (module_name, class_name, e))
                    ErrorInternal("Unable to load authz class")
                except Exception, e:
                    app.logger.exception(e)
                    app.logger.error(
                        "Unable to import authz module/class %s:%s (%s:%s)" % (module_name, class_name, type(e), e))
                    ErrorInternal("Unable to load authz module/class")
            elif authent or author:     # old configuration
                #app.logger.error("DEPRECATED: usage of old configuration method for authentication/authorization")
                g.Auth = token_based.TokenAuthent()
            else:
                #app.logger.debug("usage of empty configuration method for authentication/authorization")
                g.Auth = allow_all.FreeAuthent()

            if authent or author:
                try:
                    g.Auth.authenticate()
                except Exception, e:
                    ErrorAuth(e)

            # Init authorization module (this is just authentication step)
            # here, authorization means implicit authentication !
            # exec code just before entering api function
            before_endpoint_execution()

            # disabled API
            if "enabled" not in g.API or g.API["enabled"] == False:
                ErrorInternal("API '%s' disabled" % g.apiname)

            # add caching if asked in API definition (on read api only !)
            # direct call to cached decorator
            # use modifed version of caching extension to identify if caching has been used using arg 'by ref'
            # (list object can do this in python)
            by_ref = {}

            # identify witch codes to cache (default : errors are not cached)
            if "cacheHttpCodes" in g.API:
                by_ref["cache_http_code"] = g.API["cacheHttpCodes"]
            else:
                by_ref["cache_http_code"] = [ "*" ]

            # remove nocache from url as it prevent proper caching (data is cached on other key)
            url = request.url.encode('ascii', 'replace')
            url = re.sub("&nocache=\w+", "", url)
            url = re.sub("\?nocache=\w+&", "?", url)
            url = re.sub("\?nocache=\w+$", "", url)

            if g.API["cache"] == -1:
                cache_timeout = app.config["CACHE_TIMEOUT_API_FUNCTION"]
            else:
                cache_timeout = g.API["cache"]

            # cache url+query string+body+token
            #  (add token because there is some options associated with token that could modify processing)
            key_prefix = hashlib.md5(url).hexdigest() + hashlib.md5(request.data).hexdigest()
            if g.AuthToken is not None:
                key_prefix += hashlib.md5(g.AuthToken).hexdigest()

            if "cache" in g.API and g.API["cache"] != 0 and request.method == "GET" and not g.nocache:
                function = app.cache.cached(timeout=cache_timeout, key_prefix=key_prefix, by_ref=by_ref)(function)

            # entering api function
            try:
                r = function(*args, **kwargs)
            except HTTPException, e:
                app.logger.exception(e)
                raise e
            except Exception, e:
                # trap crash
                app.logger.exception(e)
                app.logger.error("Error executing API %s (%s)" % (g.apiname, e))
                ErrorInternal("API execution error")

            # report if api has been cached
            if "is_cached" in by_ref and by_ref["is_cached"] == True:
                g.is_cached = 1
            else:
                g.is_cached = 0

                # identify if result must be cached (if nocache is used, store result in cache)
                mustCache = False
                if "cache" in g.API and g.API["cache"] != 0 and g.nocache:
                    mustCache = True

                # look if there is a forced return http code
                try:
                    http_code = r[1]
                except Exception:
                    http_code = 200

                if "cache_http_code" in by_ref and http_code not in by_ref["cache_http_code"] and "*" not in by_ref["cache_http_code"]:
                    mustCache = False
                if mustCache == True:
                    try:
                        app.cache.set(key_prefix, r, timeout=cache_timeout)
                    except Exception:
                        app.logger.exception("Exception possibly due to cache backend.")

            # print "After running decorated function"
            return r

        # ***************************************
        # *** function post-declaration step ***
        # ***************************************

        # Check if there is swagger def for this API
        if "swagger" in api and api["swagger"] == True and api["enabled"] == True:
            # conditional call of swagger decorator (executed at function declaration)
            args = buildSwaggerArgs(api)
            wrapped = swagger.operation(**args)(wrapped)

        # print "After defined decorated function"
        return wrapped

    # print "After defined arged decorated function"
    return decorator

###########################################################################
# handler to execute at the beginning of the request
###########################################################################
@app.before_request
def before_request():
    # usefull to not log static objects (ex : swagger)
    if re.search("\.(js|jpg|gif|png|css|html)$", request.url):
        return

    # thread_id could be the same with multiple pid. Create a uniq thread_id (thread_id has to be numeric)
    g.thread_id = os.getpid() + thread.get_ident()
    if not hasattr(app, "threaded"):
        app.threaded = {}
    if g.thread_id not in app.threaded:
        app.threaded[g.thread_id] = {}
    g.app = app.threaded[g.thread_id]

    g.time_start = time.time()
    g.uuid = uuid.uuid4().hex[0:8]
    g.response_status = 0
    g.response_message = ""
    g.nocache = False  # cache allowed by default
    g.is_cached = 0  # will be populated later (in decorator)
    g.dryrun = False  # dryrun mode
    g.loglevel = app.config["LOG_LEVEL"]  # default log level
    g.debug = 0  # no debug by default
    g.logbody = 1  # default : log request body
    g.logrequest = 3  # default : log request + response
    g.remote_addr = request.remote_addr
    g.AuthToken = None  # Authorization token
    g.username = "none"
    g.userfamily = "none"
    g.auth = None  # authorization informations (token based)
    g.request_tainted = False  # no alteration of request
    g.args = None  # merge of body (json) + quesy strings vars
    g.body_json = None  # Save original body (g.args is a merge of body + query_string)
    g.schema_body = None  # json schema use to validate body

    # filter headers to log
    g.main_headers = []
    for x in request.headers:
        header = x[0].lower()
        if header == "accept" or header == "content-type":
            g.main_headers.append(x)
        # set header to force debug mode
        if header == "x-debug":
            if x[1] == "0":
                pass
            elif x[1] == "2":
                g.loglevel = "DEBUG2"
            else:
                g.loglevel = "DEBUG"

        # set header to disable cache mode
        if header == "x-nocache":
            g.nocache = True

        # set header to enable dryrun mode (simulation mode)
        if header == "x-dryrun":
            g.dryrun = True

        # if request come behind proxy (F5 pool), get real remote address
        if header == "x-forwarded-for":
            g.rproxy_addr = g.remote_addr
            g.remote_addr = x[1]

        # Authentication token
        if header == "x-authtoken":
            g.AuthToken = x[1]

    # Cache body. Need to be call very early in request, as Flask can modify it
    # (http://stackoverflow.com/questions/10999990/get-raw-post-body-in-python-flask-regardless-of-content-type-header)
    g.data = request.get_data()

    # reload config (some parts)
    Config().updateGeneralConfig()

    # Debug activation per request with adding debug arg in query string
    # (see also debug activation per request in header)
    if "debug" in request.args:
        if request.args["debug"] == "0":
            pass
        elif request.args["debug"] == "2":
            g.loglevel = "DEBUG2"
            g.debug = 2
        else:
            g.loglevel = "DEBUG"
            g.debug = 1

    # Set flask debug mode (can change some processing, as json formatting or appli auto reload with builtin web server)
    # (use global debug state as flask framework use it (ex : output json in pretty format))
    if re.search("^DEBUG", g.loglevel):
        current_app.debug = 1
    else:
        # default debug mode if not explicitly specified
        current_app.debug = app.config["DEFAULT_DEBUG"]
        g.debug = app.config["DEFAULT_DEBUG"]

    # use nocache hidden arg in query string to disable caching
    if "nocache" in request.args:
        if request.args["nocache"] == "" or request.args["nocache"] == "true" or request.args["nocache"] == "True" or request.args["nocache"] == "1":
            g.nocache = True

    # not used anymore as username come now from token
    # if request.authorization:
    #    g.username = request.authorization.username

    # Identify all hostname/alias of remote addr
    g.remote_host = []
    g.remote_host.append(getHost(g.remote_addr))
    g.remote_host.extend(getAlias(g.remote_addr))
    g.remote_host.extend(getIPx(g.remote_addr))

    if request.endpoint and request.endpoint.startswith("app/"):  # swagger url
        return

    # specific log for unknown ressources
    if request.endpoint is None:
        app.logger.error("Page not found (%s %s)" % (request.method, request.url))


###########################################################################
# handler to execute at the beginning of the request (after decorator init_api)
# (this is not a flask standard handler)
# This handler is executed AFTER 'before_request'
###########################################################################
def before_endpoint_execution():
    # let's define loglevel per API
    # can't do that before as g.API not yet defined
    if "loglevel" in g.API:
        if g.loglevel != app.config["LOG_LEVEL"]:  # loglevel already redefined (eq : per request) : do not change
            pass
        else:
            g.loglevel = g.API["loglevel"]  # set loglevel defined per api

    if "logbody" in g.API:
        try:
            g.logbody = int(g.API["logbody"])
        except Exception, e:
            app.logger.error("Invalid value for logbody in def api file (should be numeric)")

    if "logrequest" in g.API:
        try:
            g.logrequest = int(g.API["logrequest"])
        except Exception, e:
            app.logger.error("Invalid value for logrequest in def api file (should be numeric)")

    # Load dynamic rules (dynamic reconfiguration for this request : debug, audit...)
    DynRules().eval()

    # set loglevel for this request
    logger_set_loglevel(g.loglevel)

    # Set flask debug mode (can change some processing, as json formatting or appli auto reload with builtin web server)
    # (use global debug state as flask framework use it (ex : output json in pretty format))
    if g.loglevel == "DEBUG":
        current_app.debug = 1
        g.debug = 1
    elif g.loglevel == "DEBUG2":
        current_app.debug = 1
        g.debug = 2
    else:
        # default debug mode if not explicitly specified
        current_app.debug = app.config["DEFAULT_DEBUG"]
        g.debug = app.config["DEFAULT_DEBUG"]

    # Dryrun activation per request with adding dryrun arg in query string
    # (see also dryrun activation per request in header)
    # check all values as sanitization has not been yet executed (dryrun is a boolean)
    if "dryrun" in g.API and g.API["dryrun"] == True:
        if "dryrun" in request.args:
            if request.args["dryrun"] == "" or request.args["dryrun"] == "true" or request.args["dryrun"] == "True" or request.args["dryrun"] == "1":
                g.dryrun = True
            else:
                g.dryrun = False

    # log request
    logger_write_request()

    # log audit (if defined)
    g.Audit.write_request()

    # execute pre actions
    DynRules().exec_pre()


###########################################################################
# handler to execute at the end of the request
###########################################################################
@app.after_request
def after_request(response):
    # there is no endpoint
    if request.endpoint is None:
        return response

    # usefull to not log static objects (ex : swagger)
    if re.search("\.(js|gif|jpg|png|css|html)$", request.url):
        return response
    if request.endpoint.startswith("app/"):  # swagger url
        return response

    g.time_stop = time.time()
    g.delay_ms = int((g.time_stop - g.time_start) * 1000)

    # add custom headers
    response.headers.add('X-Response-Time', "%sms" % g.delay_ms)
    response.headers.add('X-API-Version', "%s" % app.config["API_VERSION"])
    response.headers.add('X-API-Name', "%s" % app.config["API_NAME"])
    if "uuid" in g:
        response.headers.add('X-UUID', "%s" % g.uuid)
    if g.is_cached:
        response.headers.add('X-Cached', "1")
    if g.dryrun:
        response.headers.add('X-Dryrun', "1")

    # add CORS (control origin) headers
    if "CORS_ALLOW_ORIGIN" in app.config:
        response.headers.add('Access-Control-Allow-Origin', app.config["CORS_ALLOW_ORIGIN"])
    if "CORS_ALLOW_METHODS" in app.config:
        response.headers.add('Access-Control-Allow-Methods', app.config["CORS_ALLOW_METHODS"])
    if "CORS_ALLOW_HEADERS" in app.config:
        response.headers.add('Access-Control-Allow-Headers', app.config["CORS_ALLOW_HEADERS"])
    if "CORS_ALLOW_CREDENTIALS" in app.config:
        response.headers.add('Access-Control-Allow-Credentials', app.config["CORS_ALLOW_CREDENTIALS"])

    # allow browser to read specific headers
    response.headers.add('Access-Control-Expose-Headers',
                         "X-Response-Time, X-API-Version, X-API-Name, X-UUID, X-Cached, X-Dryrun")

    # execute post actions
    DynRules().exec_post(response)

    # log response
    logger_write_response(response)

    # log stats
    if "Stats" in g:
        g.Stats.write(response)

    # log audit (if defined)
    if "Audit" in g:
        g.Audit.write_request()  # if request not yet audited, try again (policy could have changed after)
        g.Audit.write_response(response)

    return response

##############################################################################################
# Resolv $ref in json schema to have inline structure
##############################################################################################
def jsonschema_resolv_ref(schema, fullschema=None):
    if fullschema is None:
        fullschema = schema

        # 1st, resolve all defintions
        if "definitions" in schema:
            for field in schema["definitions"]:
                schema["definitions"][field] = jsonschema_resolv_ref(schema["definitions"][field],
                                                                     fullschema=fullschema)

    if "properties" in schema:
        for field in schema["properties"]:
            # reccursif call on objects types
            if "type" in schema["properties"][field] and schema["properties"][field]["type"] == "object":
                schema["properties"][field] = jsonschema_resolv_ref(schema["properties"][field], fullschema=fullschema)
                continue

            # track links to local document
            if "$ref" in schema["properties"][field]:
                ref = schema["properties"][field]["$ref"]
                if ref[0:2] == "#/":
                    # get the path as an array of keys to traverse the dict
                    reflist = ref[2:].split("/")
                    try:
                        resolv = reduce(dict.__getitem__, reflist, fullschema)
                    except Exception, e:
                        raise Exception("Error : invalid json schema $ref '%s' (%s)" % (ref, e))
                    schema["properties"][field] = resolv

    return schema

##############################################################################################
# fixup schema :
#  - auto fill required property based on individual field definition
##############################################################################################
def jsonschema_fixup(schema):

    # scan schema to build flat representation of each node
    for path in dpath.util.search(schema, "/**", yielded=True):
        f = path[0].split("/")
        if f[-1] == "_required":
            path_required = "/".join(f[0:-3] + ["required"])
            field = f[-2]
            required = dpath.util.get(schema, path_required)
            if field not in required:
                dpath.util.set(schema, path_required, required + [field])

    return(schema)

def jsonschema_load(schemaRef, schemaPath, schemaBasePath, f, **kwargs):
    flaskit_startup_time = gGet("flaskit_startup_time")

    # Use cached version of schema
    # schema is computed multiple time at startup (for each data class), so caching is mandatory
    if "type" not in kwargs:
        kwargs["type"] = "Request"
    key = "%s-%s" % (schemaRef, kwargs["type"])

    # verify if schema is newer than flaskit startup
    ts = gGet("%s_time" % key)
    if ts is not None and ts > flaskit_startup_time:
        schema = gGet(key)
        if schema is not None:
            return schema

    try:
        dir = "%s/%s" % (app.config["LOCAL_DIR"], "def/schemas")
        schema_filename = "%s.schema.json" % (schemaRef)

        # Load apis definition
        APIs = gGet("config.apis")
        if "apiName" not in kwargs:
            apiName = schemaRef
        else:
            apiName = kwargs["apiName"]
        if apiName not in APIs:
            raise Exception("Invalid class '%s' (unable to find valid api %s)" % (f.__name__, apiName))
        var = {
            "api": APIs[apiName],
            "ctx": {
                "name": f.__name__,
                "module": f.__module__,
                "objectClass": f.__module__ + "@" + f.__name__,
                "schemaRef": schemaRef,
            },
            "arg": kwargs,
        }

        # templatize schema
        env = jinja2.Environment(loader=jinja2.FileSystemLoader([dir, "%s/include" % dir]))
        template = env.get_template(schema_filename)
        full_schema_str = template.render(var)

    except Exception, e:
        app.logger.exception(e)
        raise Exception("Error : Unable to templatize json schema from file '%s' (%s)" % (schema_filename, e))

    # Create doc (templatized)
    if app.config["MOD_WSGI"] == False:
        try:
            if app.config["GENERATED_DOC_DIR"][0] == "/":
                dir = "%s/schemas" % app.config["GENERATED_DOC_DIR"]
            else:
                dir = "%s/%s/schemas" % (app.config["LOCAL_DIR"], app.config["GENERATED_DOC_DIR"])
            if not os.path.exists(dir):
                os.makedirs(dir)
            if "type" in kwargs:
                filename = "%s/%s.%s.schema.json" % (dir, schemaRef, kwargs["type"])
            else:
                filename = "%s/%s.schema.json" % (dir, schemaRef)

            # create doc of templatized schema file
            file = open("%s.j2" % filename, "w")
            file.write(full_schema_str)
            file.close()

        except Exception, e:
            app.logger.exception(e)
            app.logger.error("Error : Unable to save json schema j2 doc from file '%s' (%s)" % ("%s.j2" % filename, e))

    try:
        # load schema
        schema = json.loads(full_schema_str)
        schema = jsonschema_resolv_ref(schema)
        schema = jsonschema_fixup(schema)

    except Exception, e:
        raise Exception("Error : Unable to load json schema from file '%s' (%s)" % (schema_filename, e))

    # Create doc (json prety print)
    if app.config["MOD_WSGI"] == False:
        try:
            # create doc of json dump of memory schema
            file = open(filename, "w")
            file.write(json.dumps(schema, indent=4, sort_keys=True))
            file.close()

        except Exception, e:
            app.logger.exception(e)
            app.logger.error("Error : Unable to save json schema doc from file '%s' (%s)" % (filename, e))

    # Save schema + timestamp
    gSet(key, schema)
    gSet("%s_time" % key, time.time())

    return(schema)

##############################################################################################
# decorator entry point (with args)
# Generate swagger structures from api definitions (jsonschema...)
##############################################################################################
def generate_swagger_from_schema(schemaRef, schemaPath=None, schemaBasePath=None, **kwargs):
    # print "Before defined arged decorated function"

    def decorator(f):
        # print "Before defined decorated function"

        # ***************************************
        # *** function pre-declaration step ***
        # ***************************************

        schema = jsonschema_load(schemaRef, schemaPath, schemaBasePath, f, **kwargs)
        schema_part = schema
        bypass = False
        sp = ""
        if schemaBasePath is not None:
            # auto identify location with class name
            sp = "%s/%s" % (schemaBasePath, f.__name__)
        if schemaPath is not None:
            sp = schemaPath
        for field in sp.split("/"):
            if field == "":
                continue
            if field not in schema_part:
                print "Warning : wrong path '%s' for schema '%s' in decotator" % (sp, schemaRef)
                bypass = True
                break
            else:
                schema_part = schema_part[field]

        # schema loaded. Try to map fields to swagger
        if not bypass:
            kwargs2 = schema2swagger(schema_part, f, "%s/%s" % (schemaRef, schemaPath),
                                     "def/schemas/%s.schema.json" % schemaRef, schemaPath)

        # ***************************************
        # *** function execution step ***
        # ***************************************

        @wraps(f)
        def wrapped(*args, **kwargs):
            # print "Before running decorated function"

            # entering api function
            r = f(*args, **kwargs)

            # print "After running decorated function"
            return r

        # ***************************************
        # *** function post-declaration step ***
        # ***************************************

        # emulate call of following decorator (in reverse folder)
        #  @swagger.model
        #  @swagger.nested()
        if not bypass:
            # kwargs2 is a dict with all nested fields
            wrapped = swagger.nested(**kwargs2)(wrapped)
            wrapped = swagger.model(wrapped)

        # print "After defined decorated function"
        return wrapped

    # print "After defined arged decorated function"
    return decorator


##############################################################################################
# decorator entry point (with args)
# Generate swagger structures from api definitions (args in api def)
##############################################################################################
def generate_swagger_from_apidef(apiname):
    # print "Before defined arged decorated function"

    def decorator(f):
        # print "Before defined decorated function"

        # ***************************************
        # *** function pre-declaration step ***
        # ***************************************

        # Load apis definition
        APIs = gGet("config.apis")
        if apiname not in APIs:
            raise Exception("Invalid api '%s' (no description found)" % apiname)
        api = APIs[apiname]

        # default schema structure
        schema = {
            "type": "object",
            "additionalProperties": False,
            "required": [],
            "properties": {},
        }

        for field in api["args"]:
            if api["args"][field]["location"] != "body":
                continue
            schema["properties"][field] = {}
            schema["properties"][field]["description"] = api["args"][field]["description"]
            schema["properties"][field]["pattern"] = api["args"][field]["regexp"]
            schema["properties"][field]["type"] = api["args"][field]["dataType"]
            if api["args"][field]["required"]:
                schema["required"].append(field)

        # schema loaded. Try to map fields to swagger
        kwargs2 = schema2swagger(schema, f, apiname, "", "")

        # ***************************************
        # *** function execution step ***
        # ***************************************

        @wraps(f)
        def wrapped(*args, **kwargs):
            # print "Before running decorated function"

            # entering api function
            r = f(*args, **kwargs)

            # print "After running decorated function"
            return r

        # ***************************************
        # *** function post-declaration step ***
        # ***************************************

        # emulate call of following decorator (in reverse folder)
        #  @swagger.model
        #  @swagger.nested()
        # kwargs2 is a dict with all nested fields
        wrapped = swagger.nested(**kwargs2)(wrapped)
        wrapped = swagger.model(wrapped)

        # print "After defined decorated function"
        return wrapped

    # print "After defined arged decorated function"
    return decorator


def schema2swagger(schema_part, f, ref, schema_file, schema_basepath):
    # Create internal objects if not yet defined
    if "resource_fields" not in f.__dict__:
        f.__dict__["resource_fields"] = {}
    if "swagger_metadata" not in f.__dict__:
        f.__dict__["swagger_metadata"] = {}
    if "required" not in f.__dict__:
        f.__dict__["required"] = []

    nested = {}

    # Create fields in resource_fields if  not yet defined
    if "properties" in schema_part:
        for field in schema_part["properties"]:

            sp = schema_part["properties"][field]

            # field defined in python code ?
            if field in f.__dict__["resource_fields"]:

                # Field already defined in python code : do not change it
                # There will be validation at the next step
                # however, there is no way to determine nested *class name* by inspecting python instance
                # (using inspect.getmembers(class) for example)
                # We can only have informations about nested fields
                # Pb come from the way flask_restfull reference fields and not class itself
                #    resource_fields = {
                #        '_metadata': fields.Nested(_MetadataOperationFields.resource_fields),
                #        'exclusions': fields.List(fields.Nested(ExclusionsDeleteResponseSubFields.resource_fields)),
                #  -> we had to specify class name in json to have access to this information(
                if sp["type"] == "object":
                    # if class is specified in schema, get class name
                    if "_objectClass" in sp:
                        myclass = sp["_objectClass"].split("@")
                        if len(myclass) != 2:
                            raise ImportError("bad class module '%s'" % sp["_objectClass"])
                        class_name = myclass[1]
                        # fill nested struct for automatic fillup @swagger.nested decorator
                        nested[field] = class_name

                if sp["type"] == "array":
                    if "items" not in sp:
                        raise ImportError("Invalid json schema '%s' for field '%s' : missing items on array" % (schema_file, field))
                    sp = sp["items"]
                    # if class is specified in schema, get class name
                    if "_objectClass" in sp:
                        myclass = sp["_objectClass"].split("@")
                        if len(myclass) != 2:
                            raise ImportError("bad class module '%s'" % sp["_objectClass"])
                        class_name = myclass[1]
                        # fill nested struct for automatic fillup @swagger.nested decorator
                        nested[field] = class_name

            else:
                # field not defined in python code : add it in structure class from json schema
                if "type" not in sp:
                    raise Exception("Error : invalid json schema (field '%s')" % field)

                kwargs = {}
                # specify a mapping attribute from internal structure to external structure
                if "_mapped_attribute" in sp:
                    kwargs["attribute"] = sp["_mapped_attribute"]

                if sp["type"] == "integer":
                    f.__dict__["resource_fields"][field] = fields.Integer(**kwargs)

                if sp["type"] == "float":
                    f.__dict__["resource_fields"][field] = fields.Float(**kwargs)

                if sp["type"] == "string":
                    f.__dict__["resource_fields"][field] = fields.String(**kwargs)

                if sp["type"] == "boolean":
                    f.__dict__["resource_fields"][field] = fields.Boolean(**kwargs)

                # object
                if sp["type"] == "object":

                    # if class is specified in schema, create nested object of this type
                    if "_objectClass" in sp:
                        # dynamic load class
                        myclass = sp["_objectClass"].split("@")
                        if len(myclass) != 2:
                            raise ImportError("bad class module '%s'" % sp["_objectClass"])
                        try:
                            module_name = myclass[0]
                            class_name = myclass[1]
                            module = __import__(module_name, fromlist=[class_name])
                            klass = getattr(module, class_name)
                        except Exception, e:
                            raise ImportError("Unable to load class module '%s' (%s)" % (sp["_objectClass"], e))

                        f.__dict__["resource_fields"][field] = fields.Nested(klass.resource_fields, **kwargs)

                        # fill nested struct for automatic fillup @swagger.nested decorator
                        nested[field] = class_name
                    else:
                        if sp["type"] == "string":
                            f.__dict__["resource_fields"][field] = fields.Nested(fields.String, **kwargs)
                        elif sp["type"] == "integer":
                            f.__dict__["resource_fields"][field] = fields.Nested(fields.Integer, **kwargs)
                        elif sp["type"] == "boolean":
                            f.__dict__["resource_fields"][field] = fields.Nested(fields.Boolean, **kwargs)
                        else:
                            f.__dict__["resource_fields"][field] = fields.Nested(fields.Raw, **kwargs)

                # array
                if sp["type"] == "array":
                    if "items" not in sp:
                        raise ImportError("Invalid json schema '%s' for field '%s' : missing items on array" % (schema_file, field))
                    sp2 = sp["items"]

                    # if class is specified in schema, create array of nested object of this type
                    if "_objectClass" in sp2:
                        # dynamic load class
                        myclass = sp2["_objectClass"].split("@")
                        if len(myclass) != 2:
                            raise ImportError("bad class module '%s'" % sp2["_objectClass"])
                        try:
                            module_name = myclass[0]
                            class_name = myclass[1]
                            module = __import__(module_name, fromlist=[class_name])
                            klass = getattr(module, class_name)
                        except Exception, e:
                            raise ImportError("Unable to load class module '%s' (%s)" % (sp2["_objectClass"], e))

                        f.__dict__["resource_fields"][field] = fields.List(fields.Nested(fields.String, **kwargs), **kwargs)

                        # fill nested struct for automatic fillup @swagger.nested decorator
                        nested[field] = class_name
                    else:
                        if sp2["type"] == "string":
                            f.__dict__["resource_fields"][field] = fields.List(fields.String, **kwargs)
                        elif sp2["type"] == "integer":
                            f.__dict__["resource_fields"][field] = fields.List(fields.Integer, **kwargs)
                        elif sp2["type"] == "boolean":
                            f.__dict__["resource_fields"][field] = fields.List(fields.Boolean, **kwargs)
                        elif sp2["type"] == "object":
                            f.__dict__["resource_fields"][field] = fields.List(fields.Nested(fields.Raw, **kwargs), **kwargs)
                        else:
                            f.__dict__["resource_fields"][field] = fields.List(fields.Raw, **kwargs)

    try:
        # parse all internal fields and try to map to schema definition
        for field in f.__dict__["resource_fields"]:

            # First : try to detect inconsistant types definitions between jsonschema and swagger
            # try to identify class name
            if type(f.__dict__["resource_fields"][field]).__name__ == "type":
                # fields.String, fields.Integer ...
                typeobj = f.__dict__["resource_fields"][field].__module__ + "." + f.__dict__["resource_fields"][
                    field].__name__
            else:
                # fields.Nested, fields.List
                typeobj = f.__dict__["resource_fields"][field].__module__ + "." + type(
                        f.__dict__["resource_fields"][field]).__name__

            if field in schema_part["properties"]:

                # Validate that python code and json definition are aligned
                if "type" in schema_part["properties"][field]:
                    if not typeobj.startswith("flask_restful.fields."):
                        pass
                    elif schema_part["properties"][field][ "type"] == "string" and typeobj == "flask_restful.fields.String":
                        pass
                    elif schema_part["properties"][field]["type"] == "integer" and typeobj == "flask_restful.fields.Integer":
                        pass
                    elif schema_part["properties"][field]["type"] == "boolean" and typeobj == "flask_restful.fields.Boolean":
                        pass
                    elif schema_part["properties"][field]["type"] == "object" and typeobj == "flask_restful.fields.Nested":
                        pass
                    elif schema_part["properties"][field]["type"] == "array" and typeobj == "flask_restful.fields.List":
                        pass
                    elif schema_part["properties"][field]["type"] == "string" and typeobj == "flask_restful.fields.Url":
                        pass
                    else:
                        raise Exception(
                                "Invalid type equivalence for field '%s:%s' (jsonschema:'%s' vs swagger:'%s')" % (
                                    f, field, schema_part["properties"][field]["type"], typeobj))

                # create metadata for field if not yet defined
                if field not in f.__dict__["swagger_metadata"]:
                    f.__dict__["swagger_metadata"][field] = {}
                if "description" not in f.__dict__["swagger_metadata"][field]:
                    if "description" in schema_part["properties"][field]:
                        f.__dict__["swagger_metadata"][field]["description"] = schema_part["properties"][field][
                            "description"]
                if "pattern" not in f.__dict__["swagger_metadata"][field]:
                    if "pattern" in schema_part["properties"][field]:
                        f.__dict__["swagger_metadata"][field]["pattern"] = schema_part["properties"][field]["pattern"]
                if "enum" not in f.__dict__["swagger_metadata"][field]:
                    if "enum" in schema_part["properties"][field]:
                        f.__dict__["swagger_metadata"][field]["enum"] = schema_part["properties"][field]["enum"]
                if "_objectClass" not in f.__dict__["swagger_metadata"][field]:
                    if schema_part["properties"][field]["type"] == "object" and "_objectClass" in schema_part["properties"][field]:
                        f.__dict__["swagger_metadata"][field]["_objectClass"] = schema_part["properties"][field]["_objectClass"]
                    if schema_part["properties"][field]["type"] == "array" and schema_part["properties"][field]["items"]["type"] == "object" and "_objectClass" in schema_part["properties"][field]["items"]:
                        f.__dict__["swagger_metadata"][field]["_objectClass"] = schema_part["properties"][field]["items"]["_objectClass"]

            else:
                print "Warning : field '%s' is not defined in schema '%s'" % (field, ref)

            if "required" in schema_part:
                if field in schema_part["required"] and field not in f.__dict__["required"]:
                    f.__dict__["required"].append(field)

            # if this is not standards fields (ex : mapped fields), then try to override field type
            # (otherwise, this is transform to 'null' in swagger)
            if f.__dict__["resource_fields"][field].__class__.__module__ != "flask_restful.fields":
                try:
                    f.__dict__["swagger_metadata"][field]["type"] = schema_part["properties"][field]["type"]
                except:
                    pass

        if "required" in schema_part:
            for field in schema_part["required"]:
                if field not in schema_part["properties"]:
                    print "Warning : required field '%s' not defined in schema '%s'" % (field, ref)

    except Exception, e:
        raise

    # Create resulting struct as documentation in dev mode
    if app.config["MOD_WSGI"] == False:
        str = ""
        str += "#===========================================\n"
        str += "# class           : %s\n" % f.__name__
        str += "# source          : %s.py\n" % f.__module__.replace(".", "/")
        str += "# schema file     : %s\n" % schema_file
        str += "# schema basepath : %s\n" % schema_basepath
        str += "#===========================================\n"
        str += "\n"
        str += "#@generate_swagger_from_schema(schemaRef=\"%s\", schemaPath=\"%s\")\n" % (ref.split("/")[0], schema_basepath)
        str += "class %s:\n" % f.__name__
        str += "    resource_fields = {\n"
        max = 0
        for field in f.__dict__["resource_fields"]:
            if len(field) > max:
                max = len(field)
        for field in sorted(f.__dict__["resource_fields"]):
            cl = f.__dict__["resource_fields"][field]
            clName = "%s.%s" % (cl.__module__.replace("flask_restful.", ""), cl.__class__.__name__)
            if clName == "fields.String" or clName == "fields.Integer" or clName == "fields.Boolean":
                str += "        %-*.*s: %s,\n" % (max + 2, max + 2, "'" + field + "'", clName)
            if clName == "fields.List":
                cl2 = cl.container
                cl2Name = "%s.%s" % (cl2.__module__.replace("flask_restful.", ""), cl2.__class__.__name__)
                if cl2Name == "fields.String" or cl2Name == "fields.Integer" or clName == "fields.Boolean":
                    str += "        %-*.*s: %s(%s),\n" % (max + 2, max + 2, "'" + field + "'", clName, cl2Name)
                if cl2Name == "fields.Nested":
                    if "_objectClass" in f.__dict__["swagger_metadata"][field]:
                        cl3Name = f.__dict__["swagger_metadata"][field]["_objectClass"].split("@")
                        str += "        %-*.*s: %s(%s(%s.resource_fields)),\n" % (max + 2, max + 2, "'" + field + "'", clName, cl2Name, cl3Name[1])
                    else:
                        str += "        %-*.*s: %s(%s(???)),\n" % (max + 2, max + 2, "'" + field + "'", clName, cl2Name)
            if clName == "fields.Nested":
                if "_objectClass" in f.__dict__["swagger_metadata"][field]:
                    cl2Name = f.__dict__["swagger_metadata"][field]["_objectClass"].split("@")
                    str += "        %-*.*s: %s(%s.resource_fields),\n" % (max + 2, max + 2, "'" + field + "'", clName, cl2Name[1])
                else:
                    str += "        %-*.*s: %s(???),\n" % (max + 2, max + 2, "'" + field + "'", clName)
        str += "    }\n"
        if "required" in f.__dict__:
            if len(f.__dict__["required"]) == 0:
                str += "    required = []\n"
            else:
                str += "    required = [\n"
                lst = "'" + "', '".join(sorted(f.__dict__["required"])) + "'"
                str += "        %s\n" % lst
                str += "    ]\n"
        if "swagger_metadata" in f.__dict__:
            str += "    swagger_metadata = {\n"
            max = 0
            for field in f.__dict__["swagger_metadata"]:
                if len(field) > max:
                    max = len(field)
            for field in sorted(f.__dict__["swagger_metadata"]):
                str += "        %-*.*s: {\n" % (max + 2, max + 2, "'" + field + "'")

                max2 = 0
                for field2 in f.__dict__["swagger_metadata"][field]:
                    if len(field2) > max2:
                        max2 = len(field2)
                for field2 in sorted(f.__dict__["swagger_metadata"][field]):
                    if type(f.__dict__["swagger_metadata"][field][field2]) is list:
                        str += "            %-*.*s: %s,\n" % (
                            max2 + 2, max2 + 2, "'" + field2 + "'", json.dumps(f.__dict__["swagger_metadata"][field][field2]))
                    else:
                        str += "            %-*.*s: '%s',\n" % (
                            max2 + 2, max2 + 2, "'" + field2 + "'", f.__dict__["swagger_metadata"][field][field2])
                str += "        },\n"

            str += "    }\n"

            str += "\n"
            str += "\n"

        if app.config["GENERATED_DOC_DIR"][0] == "/":
            dir = "%s/classes" % app.config["GENERATED_DOC_DIR"]
        else:
            dir = "%s/%s/classes" % (app.config["LOCAL_DIR"], app.config["GENERATED_DOC_DIR"])
        if not os.path.exists(dir):
            os.makedirs(dir)
        filename = "%s/resource.%s.class" % (dir, f.__name__)
        file = open(filename, "w")
        file.write(str)
        file.close()

    return nested


####################################################
# Super resource class
####################################################
class MetaResource(restful.Resource):
    def __init__(self):

        g.status = 0
        g.message = ""

    ##############################################################################
    # Initialize API
    ##############################################################################
    def initializeAPI(self, data={}):

        # verif request
        g.args = self.GetParams(data=data)

        g.ApiOptions = {}

        # verify authorization first if ask for this api
        if "authorization" in g.API and g.API["authorization"] == True:
            g.ApiOptions = g.Auth.authorize(g.args, abort=True, check_acls=g.API["authorizationCheckAcls"])

        # if var defined in config and o token options, verify that it matches (allow to limit a toekn to a specific environment)
        if "FLASKIT_ENV" in app.config and "FLASKIT_ENV" in g.ApiOptions:
            if app.config["FLASKIT_ENV"] != g.ApiOptions["FLASKIT_ENV"]:
                ErrorAuth("Invalid env token (%s) for platform (%s)" % (g.ApiOptions["FLASKIT_ENV"], app.config["FLASKIT_ENV"]))

    ##############################################################################
    # Generic sanatizer call
    ##############################################################################
    def GetParams(self, data):

        try:
            sanatizer = Sanatize()
            params = sanatizer.get(data)
        except ValueError, e:
            if isinstance(e.message, dict):
                msg = e.message["message"]
                del e.message["message"]
                data = e.message
            else:
                if not g.debug:
                    msg = str(e).split('\n', 1)[0]
                else:
                    msg = str(e)
                data = None
            app.logger.error("%s" % e)
            ErrorParams("%s" % msg, status=2, data=data)
        except Exception, e:
            app.logger.exception(e)
            app.logger.error("%s" % e)
            ErrorInternal("Validation module")

        return params
